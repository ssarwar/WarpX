// Standalone diagnostic linked to the existing production PJG object.
// Writes native float64 records for the independent Python audit.
#include "Particles/Collision/ProtonImpactIonization/PJGModel.H"

#include <AMReX.H>

#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>

int main (int argc, char** argv)
{
    amrex::Initialize(argc, argv);
    {
        constexpr double proton_rest_energy = 938272088.16;
        std::ofstream output("tmp/pjg_table_audit.bin", std::ios::binary);
        std::vector<double> energies{1.0e3, 5.0e3, 50.0e3, 200.0e3, 500.0e3,
                                     1.0e6, 10.0e6, 100.0e6, 800.0e6, 1.0e9};
        for (int i = 0; i < 64; ++i) {
            energies.push_back(std::exp(std::log(1.0e3) + (i + 0.5) / 64 * std::log(1.0e6)));
        }
        using ProtonImpactIonization::PJGModel;
        using ProtonImpactIonization::PJGTarget;
        for (int species = 0; species < 2; ++species) {
            auto const target = species == 0 ? PJGTarget::N2 : PJGTarget::O2;
            PJGModel model(target, proton_rest_energy, 1.0e3, 1.0e9);
            auto const executor = model.executor();
            for (auto const energy : energies) {
                auto const total = PJGModel::integratedCrossSection(target, energy, proton_rest_energy);
                auto const table_total = executor.crossSection(energy);
                auto const maximum = PJGModel::maximumEnergyTransfer(energy, proton_rest_energy);
                auto const device_maximum = executor.maximumEnergyTransfer(energy);
                for (int i = 0; i <= 2048; ++i) {
                    auto const x = static_cast<double>(i) / 2048;
                    auto const q = std::pow(x, 4) / (std::pow(x, 4) + std::pow(1 - x, 4));
                    amrex::ParticleReal secondary = 0.0;
                    amrex::ParticleReal binding = 0.0;
                    executor.sample(energy, q, secondary, binding);
                    auto const sdcs = PJGModel::differentialCrossSection(
                        target, energy, secondary, proton_rest_energy);
                    std::array<double, 10> const record{
                        static_cast<double>(species), energy, q, total, table_total,
                        maximum, device_maximum, secondary, binding, sdcs};
                    output.write(reinterpret_cast<char const*>(record.data()), sizeof(record));
                }
            }
            std::cout << "Audited target " << species << ", " << energies.size()
                      << " energies, 2049 quantiles per energy\n";
        }
    }
    amrex::Finalize();
}
