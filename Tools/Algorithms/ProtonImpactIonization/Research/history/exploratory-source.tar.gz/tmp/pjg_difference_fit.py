"""Nonrelativistic, PJG-preserving shape test with Rudd's bound cutoff.

This separates the data-fit question from relativistic endpoint broadening.
It is not a production SDCS and is not extrapolated to relativistic energies.
"""

import json
from pathlib import Path

import numpy as np
from scipy.integrate import simpson
from scipy.optimize import least_squares
from scipy.special import expit

from pjg_reference import N2, O2
from pjg_rebuild_experiment import CB, ME, MP, RY, rudd_sdcs, rudd_total


class Batch:
    def __init__(self, target, energy, secondary):
        self.p = target
        self.energy, self.t = np.broadcast_arrays(energy, secondary)
        self.ek = self.energy * ME / MP
        self.wide = self.t[..., None] + target.thresholds
        self.logs = np.log(4 * self.ek[..., None] * target.c / target.thresholds + np.e)
        v = np.sqrt(self.ek[..., None] / target.thresholds)
        self.cutoff = expit((.7 if target.name == "N2" else .59) * (
            4 * self.ek[..., None] - 2 * v * target.thresholds - RY / 4 - self.t[..., None]
        ) / (v * target.thresholds))

    def __call__(self, parameters):
        j, power, amplitude, gs, gn, ts, tn, broad = parameters
        p = self.p
        width = gs + gn / (self.ek + p.gamma_2)
        center = ts - tn / (self.ek + p.t_b)
        # Parameter broad is a nonnegative excess width, retaining positivity.
        broad2 = width**2 + broad**2
        denominator = (self.t - center)**2 + width**2
        soft_shape = broad**2 / (denominator * ((self.t - center)**2 + broad2))
        hard_shape = 1 / ((self.t - center)**2 + broad2)
        distortion = expit(power * np.log(self.ek / j))
        kernel = (amplitude * p.k * width[..., None]**2 * self.logs * soft_shape[..., None]
                  + p.ne * CB * hard_shape[..., None])
        return distortion / self.ek * np.sum(p.fractions * kernel * self.cutoff, axis=-1)


def main():
    for target in (N2, O2):
        energies = np.geomspace(5.e3, 4.e6, 31)
        x = np.linspace(0, 1, 2049)[None, :] * np.log1p(energies[:, None])
        t = np.expm1(x)
        grid = Batch(target, energies[:, None], t)
        expected_total = rudd_total(target.name, energies)
        es = ([5.e3, 10.e3, 30.e3, 50.e3, 100.e3, 300.e3, 1.e6]
              if target.name == "N2" else [7.5e3, 10.e3, 30.e3, 50.e3, 100.e3, 300.e3])
        se, st, sy = [], [], []
        for energy in es:
            tt = np.geomspace(2, min(8 * energy * ME / MP, 3000), 48)
            yy = rudd_sdcs(target.name, energy, tt)
            keep = yy > yy[0] * 1.e-4
            se.extend([energy] * np.count_nonzero(keep))
            st.extend(tt[keep])
            sy.extend(yy[keep])
        spectra = Batch(target, se, st)
        expected_sdcs = np.array(sy)
        defaults = np.array([target.j, target.nu+1, 1, target.gamma_s,
                             target.gamma_1, target.t_s, target.t_a,
                             target.gamma1_fixed])
        # Refit only existing PJG degrees of freedom; no per-energy fit values.
        for active in ([0], [0,1,2], [0,1,2,3,7], [0,1,2,3,4,5,6,7]):
            def unpack(parameters):
                p = defaults.copy()
                p[active] = parameters
                return p

            scales = defaults[active]
            def residual(parameters):
                p = unpack(parameters * scales)
                total = simpson(grid(p) * np.exp(x), x=x, axis=-1)
                rt = np.log(total / expected_total)
                rs = np.log(spectra(p) / expected_sdcs)
                return np.concatenate((rt / np.sqrt(len(rt)), rs / np.sqrt(len(rs))))

            lo = np.array([.01,.1,.01,.1,0,-50,0,1])[active] / scales
            hi = np.array([1.e5,4,20,100,1.e7,50,1.e6,1000])[active] / scales
            fit = least_squares(residual, np.ones(len(active)), bounds=(lo,hi),
                                max_nfev=600, ftol=1.e-9, xtol=1.e-9)
            p = unpack(fit.x * scales)
            total = simpson(grid(p) * np.exp(x), x=x, axis=-1)
            ratio = spectra(p) / expected_sdcs
            tail = simpson(np.where(t > 4 * grid.ek, grid(p), 0) * np.exp(x),
                           x=x, axis=-1) / total
            result = dict(target=target.name, active=active, parameters=p.tolist(),
                          total_ratio=(total / expected_total).tolist(),
                          sdcs_ratio=ratio.tolist(), sdcs_energy=se, sdcs_secondary=st,
                          tail_fraction=tail.tolist(), energies=energies.tolist())
            print(target.name, len(active), p, "total", np.min(total/expected_total),
                  np.max(total/expected_total), "SDCS", np.percentile(ratio, [0,10,50,90,100]),
                  "tail 5keV", tail[0], flush=True)
            Path(__file__).with_name(f"difference-fit-{target.name}-{len(active)}.json").write_text(
                json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
