"""PJG-preserving tail-repair diagnostics; not a production model."""

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.integrate import simpson
from scipy.optimize import least_squares
from scipy.special import expit

from pjg_reference import N2, O2
from pjg_rebuild_experiment import CB, ME, MP, kinematics, rudd_sdcs, rudd_total
from pjg_gos_experiment import molecular_maximum


class Batch:
    def __init__(self, target, energy, secondary, exponent=1, cutoff="none", structure="blend"):
        self.p = target
        self.energy, self.t = np.broadcast_arrays(energy, secondary)
        self.exponent = exponent
        self.cutoff = cutoff
        self.structure = structure
        self.beta2, self.gamma, self.ee, self.maximum = kinematics(self.energy)
        self.width = target.gamma_s + target.gamma_1 / (self.ee + target.gamma_2)
        self.center = target.t_s - target.t_a / (self.ee + target.t_b)
        self.logarithm = sum(f * (np.log(4 * self.ee * c / i * self.gamma**2 + np.e)
                                 - self.beta2)
                             for f, i, c in zip(target.fractions, target.thresholds,
                                                target.c, strict=True))
        x = np.minimum(self.t / self.maximum, 1)
        self.bhabha = (1 - x) + x / self.gamma**2
        self.bhabha += .5 * (np.minimum(self.t, self.maximum) / (self.energy + MP))**2
        self.bhabha = np.where(self.t <= self.maximum, self.bhabha, 0)
        self.endpoint = molecular_maximum(target.name, self.energy, target.thresholds[0])

    def __call__(self, parameters):
        j, power, amplitude, width_scale = parameters
        width = self.width * width_scale
        shape = width**2 / ((self.t - self.center)**2 + width**2)
        soft_fraction = (width**2 / (self.t**2 + width**2))**self.exponent
        distortion = expit(power * np.log(self.energy * ME / MP / j))
        soft = amplitude * self.p.k * self.logarithm * soft_fraction
        hard = self.p.ne * CB / width**2 * (1 - soft_fraction) * self.bhabha
        if self.structure == "difference":
            wide = self.p.gamma1_fixed
            broad_ratio = ((self.t - self.center)**2 + width**2) / (
                (self.t - self.center)**2 + wide**2)
            soft = amplitude * self.p.k * self.logarithm * (1 - broad_ratio)
            hard = self.p.ne * CB / width**2 * broad_ratio * self.bhabha / distortion
            hard *= self.t + self.p.thresholds[0] <= self.maximum
        if self.cutoff == "rudd":
            # Diagnostic use of Rudd's published bound-state cutoff, not new kinematics.
            i = self.p.thresholds[0]
            alpha = .7 if self.p.name == "N2" else .59
            v = np.sqrt(self.ee / i)
            wc = self.maximum - 2 * v * i - 13.605693122994 / 4
            soft *= expit(alpha * (wc - self.t) / (v * i))
        result = distortion / self.ee * shape * (soft + hard)
        return np.where((self.t >= 0) & (self.t < self.endpoint), result, 0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--exponent", type=float, default=1)
    parser.add_argument("--cutoff", default="none")
    parser.add_argument("--structure", default="blend")
    args = parser.parse_args()
    for target in (N2, O2):
        energies = np.geomspace(5.e3, 4.e6, 31)
        maximum = molecular_maximum(target.name, energies, target.thresholds[0])
        x = np.linspace(0, 1, 2049)[None, :] * np.log1p(maximum[:, None])
        t = np.expm1(x)
        grid = Batch(target, energies[:, None], t, args.exponent, args.cutoff, args.structure)
        expected_total = rudd_total(target.name, energies)
        es = ([5.e3, 10.e3, 30.e3, 50.e3, 100.e3, 300.e3, 1.e6]
              if target.name == "N2" else [7.5e3, 10.e3, 30.e3, 50.e3, 100.e3, 300.e3])
        se, st, sy = [], [], []
        for energy in es:
            tt = np.geomspace(2, min(2 * kinematics(energy)[3], 3000), 48)
            yy = rudd_sdcs(target.name, energy, tt)
            keep = yy > yy[0] * 1.e-4
            se.extend([energy] * np.count_nonzero(keep))
            st.extend(tt[keep])
            sy.extend(yy[keep])
        spectra = Batch(target, se, st, args.exponent, args.cutoff, args.structure)
        expected_sdcs = np.array(sy)
        for count in (1, 2, 3, 4):
            defaults = np.array([target.j, target.nu + 1, 1, 1])

            def unpack(log_parameters):
                p = defaults.copy()
                p[:count] = np.exp(log_parameters)
                return p

            def residual(log_parameters):
                p = unpack(log_parameters)
                total = simpson(grid(p) * np.exp(x), x=x, axis=-1)
                rt = np.log(total / expected_total)
                rs = np.log(spectra(p) / expected_sdcs)
                return np.concatenate((rt / np.sqrt(len(rt)), rs / np.sqrt(len(rs))))

            fit = least_squares(residual, np.log(defaults[:count]),
                                bounds=(np.log([.01, .1, .02, .1][:count]),
                                        np.log([1.e5, 4, 20, 10][:count])))
            p = unpack(fit.x)
            total = simpson(grid(p) * np.exp(x), x=x, axis=-1)
            ratio = spectra(p) / expected_sdcs
            tail = simpson(np.where(grid.t > grid.maximum, grid(p), 0) * np.exp(x),
                           x=x, axis=-1) / total
            result = dict(target=target.name, count=count, exponent=args.exponent,
                          cutoff=args.cutoff, parameters=p.tolist(),
                          total_ratio=(total / expected_total).tolist(),
                          sdcs_ratio=ratio.tolist(), sdcs_energy=se, sdcs_secondary=st,
                          tail_fraction=tail.tolist(), energies=energies.tolist())
            print(target.name, count, p, "total", np.min(total/expected_total),
                  np.max(total/expected_total), "SDCS", np.percentile(ratio, [0,10,50,90,100]),
                  "tail 5keV", tail[0], flush=True)
            output = Path(__file__).with_name(
                f"minimal-{args.structure}-{target.name}-{args.cutoff}-{args.exponent:g}-{count}.json")
            output.write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
