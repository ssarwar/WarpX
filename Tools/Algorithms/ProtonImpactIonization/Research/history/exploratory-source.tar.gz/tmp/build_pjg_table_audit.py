"""Compile a standalone diagnostic using this worktree's existing build flags."""

from pathlib import Path
import shlex
import subprocess

root = Path(__file__).resolve().parents[1]
flags = {}
for line in (root / "build/CMakeFiles/lib_3d.dir/flags.make").read_text().splitlines():
    if " = " in line:
        key, value = line.split(" = ", 1)
        flags[key] = shlex.split(value)
compiler = "/Users/ssarwar/miniconda3/envs/warpx-cpu-mpich-dev/bin/arm64-apple-darwin20.0.0-clang++"
environment_lib = "/Users/ssarwar/miniconda3/envs/warpx-cpu-mpich-dev/lib"
subprocess.run([
    compiler, *flags["CXX_DEFINES"], *flags["CXX_INCLUDES"], *flags["CXX_FLAGS"],
    "tmp/pjg_table_audit.cpp",
    "build/CMakeFiles/lib_3d.dir/Source/Particles/Collision/ProtonImpactIonization/PJGModel.cpp.o",
    "build/lib/libablastr_3d.a", "build/lib/libamrex_3d.dylib",
    f"-L{environment_lib}", "-lmpi", "-lomp",
    f"-Wl,-rpath,{root}/build/lib", f"-Wl,-rpath,{environment_lib}",
    "-o", "build/bin/pjg_table_audit",
], cwd=root, check=True)
