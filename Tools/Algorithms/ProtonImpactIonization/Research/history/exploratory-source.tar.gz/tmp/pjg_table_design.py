import sys
from pathlib import Path

import numpy as np
from scipy.integrate import cumulative_trapezoid
from numpy.polynomial.legendre import leggauss

sys.path.insert(0, str(Path.cwd() / "Tools/Algorithms/ProtonImpactIonization"))
from calibrated_pjg import PARAMETERS
from stopping_pjg_matched import LossGrid

nodes, weights = leggauss(24)
for target, p in PARAMETERS.items():
    for energy in [5e3, 1e6, 800e6, 1e10]:
        grid = LossGrid(target, [energy], points=8193)
        m = grid(p)
        y = (grid.grid(p) * grid.jacobian)[0]
        prefix = cumulative_trapezoid(y, dx=grid.dx, initial=0)
        prefix += np.r_[0, np.cumsum(prefix[:-1, -1])][:, None]
        suffix = cumulative_trapezoid(y[::-1, ::-1], dx=grid.dx, initial=0)
        suffix += np.r_[0, np.cumsum(suffix[:-1, -1])][:, None]
        total = prefix[-1, -1]
        t = np.r_[grid.secondary[0, 0], grid.secondary[0, 1:, 1:].ravel()]
        c = np.r_[prefix[0], prefix[1:, 1:].ravel()] / total
        s = np.r_[suffix[0], suffix[1:, 1:].ravel()] / total
        for count in [513, 1025, 2049]:
            x = np.linspace(0, 1, count)
            q = x**4 / (x**4 + (1-x)**4)
            r = (1-x)**4 / (x**4 + (1-x)**4)
            table = np.where(x <= .5, np.interp(q, c, t), np.interp(r, s, t[::-1]))
            table[0], table[-1] = 0, t[-1]
            u = (np.arange(count-1)[:, None] + (nodes+1)/2) / (count-1)
            tt = np.expm1(np.log1p(table[:-1, None]) * (1-(nodes+1)/2) + np.log1p(table[1:, None]) * ((nodes+1)/2))
            dq = 4 * u**3 * (1-u)**3 / (u**4 + (1-u)**4)**2
            predicted = [(tt**order * dq * weights / (2*(count-1))).sum() for order in [1, 2]]
            print(target, energy, count, "moment-ratio", predicted / np.array([m.kinetic[0]/m.total[0], m.kinetic_second[0]/m.total[0]]), flush=True)
