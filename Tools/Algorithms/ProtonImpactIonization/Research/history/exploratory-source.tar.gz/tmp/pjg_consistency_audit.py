"""Independent, bounded physics/numerics audit; no production changes."""

import json
import math
from pathlib import Path

import numpy as np
from scipy.integrate import quad, simpson
from scipy.optimize import brentq

from pjg_limit_audit import N2, O2, ME, MP, PI_E4, state, terms, sdcs, bhabha


def continuum(target, energy, t, variant="refit"):
    p, b2, ee, cut, oldcut, g, a, b, d, logs, _ = terms(target, energy, variant)
    t = np.asarray(t)[..., None]
    shape = 1 / ((t-a)**2+g*g) - b / ((t-p.t1)**2+p.gamma1_fixed**2)
    if variant == "printed":
        hard = 1 / (4*(energy+2*MP)**2) - 1/((oldcut+p.thresholds+p.delta)*(t+p.thresholds))
    else:
        hard = 1 / (2*(energy+MP)**2) - b2/((cut+p.thresholds)*(t+p.thresholds))
    return d/ee*p.fractions*(p.k*g*g*logs*shape+p.ne*PI_E4*hard)


def lorentz_moments(u, center, width):
    angle = np.arctan2(u*width, width**2+center**2-center*u)
    zeroth = angle/width
    log_ratio = np.log1p((u*u-2*center*u)/(center**2+width**2))
    return (zeroth, .5*log_ratio+center*zeroth,
            u+center*log_ratio+(center**2-width**2)*zeroth)


def moments(target, energy, upper=None, variant="refit", per_shell=False):
    p,b2,ee,cut,oldcut,g,a,b,d,logs,_ = terms(target,energy,variant)
    if upper is None:
        upper=oldcut if variant=="printed" else cut
    u=np.asarray(upper)[...,None]
    i=p.thresholds
    lm=lorentz_moments(u,a,g)
    l1=lorentz_moments(u,p.t1,p.gamma1_fixed)
    log=np.log1p(u/i)
    hm=(log, u-i*log, u*u/2-i*u+i*i*log)
    if variant=="printed":
        const=1/(4*(energy+2*MP)**2)
        inv=1/(oldcut+i+p.delta)
    else:
        const=1/(2*(energy+MP)**2)
        inv=b2/(cut+i)
    out=[]
    for n in range(3):
        vals=d/ee*p.fractions*(p.k*g*g*logs*(lm[n]-b*l1[n])+
                              p.ne*PI_E4*(const*u**(n+1)/(n+1)-inv*hm[n]))
        out.append(vals if per_shell else np.sum(vals,axis=-1))
    return np.asarray(out)


def draw_inverse(target,energy,q):
    lo=np.zeros_like(q)
    hi=np.full_like(q,state(energy)[3])
    total=moments(target,energy)[0]
    for _ in range(60):
        mid=(lo+hi)/2
        below=moments(target,energy,mid)[0]<q*total
        lo=np.where(below,mid,lo)
        hi=np.where(below,hi,mid)
    return (lo+hi)/2


def audit():
    result={}
    energy_grid=np.geomspace(1e3,1e9,1001)
    for target in (N2,O2):
        target_results={}
        assert np.isclose(np.sum(target.fractions),1,atol=1e-15)
        for variant in ("printed","corrected","refit"):
            negative_energies=[]
            negative_continua=[]
            min_total=math.inf
            for e in energy_grid:
                cut=state(e)[4 if variant=="printed" else 3]
                t=np.expm1(np.linspace(0,np.log1p(cut),2049))
                comp=continuum(target,e,t,variant)
                whole=np.sum(comp,axis=-1)
                if np.min(whole)<0:
                    negative_energies.append(float(e))
                if np.min(comp)<0:
                    negative_continua.append(float(e))
                min_total=min(min_total,float(moments(target,e,variant=variant)[0]))
            target_results[variant]={"negative_beam_energies":negative_energies,
                                     "negative_continuum_beam_energies":negative_continua,
                                     "min_total_cm2":min_total}
        quad_errors=[]
        moment_rows=[]
        for e in (1e3,5e3,50e3,200e3,500e3,1e6,10e6,100e6,800e6,1e9):
            cut=state(e)[3]
            exact=moments(target,e)
            for n in range(3):
                numerical=quad(lambda x: float(sdcs(target,e,np.expm1(x),"refit")) *
                               np.expm1(x)**n*np.exp(x)/exact[n],0,np.log1p(cut),
                               epsabs=1e-10,epsrel=1e-10,limit=200)[0]
                quad_errors.append(abs(numerical-1))
            mean=exact[1]/exact[0]
            second=exact[2]/exact[0]
            assert 0 <= mean <= cut
            assert mean*mean <= second <= cut*mean
            bindings=np.sum(moments(target,e,per_shell=True)[0]*target.thresholds)/exact[0]
            assert target.thresholds.min()<=bindings<=target.thresholds.max()
            low_fraction=moments(target,e,min(cut,target.thresholds[0]))[0]/exact[0]
            moment_rows.append({"E_eV":e,"sigma_cm2":float(exact[0]),"mean_T_eV":float(mean),
                                "mean_I_eV":float(bindings),"second_T_eV2":float(second),
                                "fraction_T_below_I1":float(low_fraction)})
        target_results["max_quadrature_relative_error_m0_m1_m2"]=max(quad_errors)
        target_results["moments"]=moment_rows
        # Compare finite differences of an independently expressed cumulative to SDCS.
        derivative_errors=[]
        for e in (1e3,50e3,1e6,800e6):
            for t in np.geomspace(1e-4,.95*state(e)[3],101):
                h=t*1e-4
                derivative=(moments(target,e,t+h)[0]-moments(target,e,t-h)[0])/(2*h)
                derivative_errors.append(abs(derivative/float(sdcs(target,e,t,"refit"))-1))
        target_results["max_cdf_derivative_relative_error"]=max(derivative_errors)
        # Model extrapolation, not the default table domain.
        target_results["below_ionization_threshold"]={str(e):float(moments(target,e)[0])
                                                      for e in (1.,5.,10.)}
        result[target.name]=target_results
    # Check actual production double-precision reference and lookup executor.
    records=np.fromfile("tmp/pjg_table_audit.bin",dtype=np.float64).reshape(-1,2049,10)
    lookup={}
    for j,target in enumerate((N2,O2)):
        errors={"cdf_abs":[],"cross_section_rel":[],"host_total_rel":[],"host_sdcs_rel":[],
                "sample_mean_rel":[],"sample_second_moment_rel":[],"binding_abs_eV":[],
                "monotone":True,"within_support":True}
        for record in records[records[:,0,0]==j]:
            e=record[0,1]
            q=record[:,2]
            t=record[:,7]
            exact=moments(target,e)
            cdf=moments(target,e,t)[0]/exact[0]
            x=np.linspace(0,1,len(t))
            jac=4*x**3*(1-x)**3/(x**4+(1-x)**4)**2
            errors["cdf_abs"].append(float(np.max(np.abs(cdf-q))))
            errors["cross_section_rel"].append(abs(record[0,4]/(1e-4*exact[0])-1))
            errors["host_total_rel"].append(abs(record[0,3]/(1e-4*exact[0])-1))
            reference=sdcs(target,e,t,"refit")*1e-4
            errors["host_sdcs_rel"].append(float(np.max(np.abs(record[:,9]/reference-1))))
            for n,key in ((1,"sample_mean_rel"),(2,"sample_second_moment_rel")):
                numerical=simpson(t**n*jac,x=x)
                errors[key].append(abs(numerical/(exact[n]/exact[0])-1))
            comp=continuum(target,e,t)
            ieff=np.sum(comp*target.thresholds,axis=-1)/np.sum(comp,axis=-1)
            errors["binding_abs_eV"].append(float(np.max(np.abs(record[:,8]-ieff))))
            errors["monotone"] &= bool(np.all(np.diff(t)>=0))
            errors["within_support"] &= bool(np.min(t)>=0 and np.max(t)<=record[0,5])
        lookup[target.name]={k:bool(v) if isinstance(v,bool) else float(max(v))
                             for k,v in errors.items()}
    result["production_double_lookup_max_errors"]=lookup
    # Confirm the sampling-order counterexample in continuum quadrature: equal
    # parent-selection scores, low energy parents first, high energy parents last.
    x,w=np.polynomial.legendre.leggauss(512)
    q=(x+1)/2
    order={}
    for target in (N2,O2):
        low,high=50e3,800e6
        proper=(moments(target,low)[1]/moments(target,low)[0]+
                moments(target,high)[1]/moments(target,high)[0])/2
        # Integrate in transformed quantile to resolve both endpoints accurately.
        xf=(x+1)/2
        qf=xf**4/(xf**4+(1-xf)**4)
        jac=4*xf**3*(1-xf)**3/(xf**4+(1-xf)**4)**2
        mean_lower_low=np.sum(w/2*draw_inverse(target,low,.5*qf)*jac)*.5
        mean_upper_high=np.sum(w/2*draw_inverse(target,high,.5+.5*qf)*jac)*.5
        mean_upper_low=np.sum(w/2*draw_inverse(target,low,.5+.5*qf)*jac)*.5
        mean_lower_high=np.sum(w/2*draw_inverse(target,high,.5*qf)*jac)*.5
        order[target.name]={"correct_mean_eV":float(proper),
                            "low_then_high_mean_eV":float(mean_lower_low+mean_upper_high),
                            "high_then_low_mean_eV":float(mean_upper_low+mean_lower_high)}
    result["parent_energy_order_counterexample"]=order
    # IEEE float32 arithmetic emulation of the executor's free-electron Tmax.
    floats=[]
    for mass_ratio in (1,12,16,238):
        for energy in (1e3,5e3,50e3,1e6):
            f=np.float32
            m=f(mass_ratio*MP)
            g=f(1)+f(energy)/m
            b=f(1)-f(1)/(g*g)
            r=f(ME)/m
            tm=f(2)*f(ME)*b*g*g/(f(1)+f(2)*g*r+r*r)
            exact=2*ME*energy*(energy+2*mass_ratio*MP)/(
                (mass_ratio*MP)**2+ME**2+2*ME*(energy+mass_ratio*MP))
            floats.append({"M_over_Mp":mass_ratio,"E_eV":energy,"Tmax_float_eV":float(tm),
                           "Tmax_exact_eV":exact,"relative_error":float(tm/exact-1)})
    result["float32_Tmax_emulation"]=floats
    Path("tmp/pjg_consistency_audit_results.json").write_text(json.dumps(result,indent=2)+"\n")
    for name in ("N2","O2"):
        print(name)
        for variant in ("printed","corrected","refit"):
            data=result[name][variant]
            a=data["negative_beam_energies"]
            b=data["negative_continuum_beam_energies"]
            print(variant,"negative grid energies:",len(a),"range:", (a[0],a[-1]) if a else None,
                  "negative continua grid energies:",len(b),"min total:",data["min_total_cm2"])
        print("quadrature:",result[name]["max_quadrature_relative_error_m0_m1_m2"],
              "CDF derivative:",result[name]["max_cdf_derivative_relative_error"])
        print("moments:",result[name]["moments"])
    print("PRODUCTION TABLE:",lookup)
    print("ORDER BIAS:",order)
    print("FLOAT32:",floats)
    print("Results: tmp/pjg_consistency_audit_results.json")


if __name__=="__main__":
    audit()
