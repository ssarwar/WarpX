"""Read-only physics audit of PJG limits; energies in eV, SDCS in cm^2/eV.

Parameters are transcribed from PJG Table III in pjg_reference.py. This audit
uses independent expressions, including the printed cutoff for the printed
model (the older scratch sdcs routine does not make that substitution).
No production source is changed. Formal tail tests outside kinematic support
test algebra only, not a physical extrapolation.
"""

from dataclasses import replace
import math

import numpy as np
from scipy.optimize import brentq

from pjg_reference import N2, O2

ME = 510998.95069
MP = 938272088.16
RE = 2.8179403205e-13
PI_E4 = math.pi * (RE * ME) ** 2


def state(energy):
    gamma = 1 + energy / MP
    beta2 = energy * (energy + 2 * MP) / (energy + MP) ** 2
    ee = ME * beta2 / 2
    maximum = 2 * ME * energy * (energy + 2 * MP) / (
        MP**2 + ME**2 + 2 * ME * (energy + MP)
    )
    printed_maximum = energy * (energy + 2 * MP) / (
        energy + ME + MP / ME * (energy + MP)
    )
    return gamma, beta2, ee, maximum, printed_maximum


def target_for(target, variant):
    if variant == "refit":
        return replace(target, j=59.65 if target.name == "N2" else 19.28,
                       k=target.k if target.name == "N2" else 4.581e-16,
                       delta=0)
    if variant == "corrected":
        return replace(target, delta=0)
    return target


def terms(target, energy, variant):
    target = target_for(target, variant)
    gamma, beta2, ee, maximum, printed_maximum = state(energy)
    width = target.gamma_s + target.gamma_1 / (ee + target.gamma_2)
    center = target.t_s - target.t_a / (ee + target.t_b)
    reduction = target.b0 * (math.log(ee / target.e0)**2 + target.b1)
    distortion = 1 / (1 + (target.j / ee)**(target.nu + 1))
    log_factor = np.log(4 * ee * target.c / target.thresholds * gamma**2 + math.e) - beta2
    a = target.k * width**2 * (1 - reduction) * (target.fractions @ log_factor) / (
        target.ne * PI_E4
    )
    return target, beta2, ee, maximum, printed_maximum, width, center, reduction, distortion, log_factor, a


def soft_shape(t, width, center, target, reduction):
    return 1 / ((t - center)**2 + width**2) - reduction / (
        (t - target.t1)**2 + target.gamma1_fixed**2
    )


def sdcs(target, energy, t, variant):
    p, beta2, ee, maximum, printed, width, center, reduction, distortion, logs, _ = terms(
        target, energy, variant
    )
    t = np.asarray(t)
    soft = p.k * width**2 * (p.fractions @ logs) * soft_shape(t, width, center, p, reduction)
    w = t[..., None] + p.thresholds
    if variant == "printed":
        hard = p.ne * PI_E4 * np.sum(p.fractions * (
            1 / (4 * (energy + 2 * MP)**2) - 1 / ((printed + p.thresholds + p.delta) * w)
        ), axis=-1)
    else:
        hard = p.ne * PI_E4 * np.sum(p.fractions * (
            1 / (2 * (energy + MP)**2) - beta2 / ((maximum + p.thresholds) * w)
        ), axis=-1)
    return distortion / ee * (soft + hard)


def bhabha(ne, energy, w):
    _, beta2, ee, maximum, _ = state(energy)
    return ne * PI_E4 / ee / w**2 * (
        1 - beta2 * w / maximum + w**2 / (2 * (energy + MP)**2)
    )


def bhabha_q(ne, energy, w):
    gamma = 1 + energy / MP
    q = w / energy
    qm = 2 * ME * MP * (gamma + 1) / (ME**2 + MP**2 + 2 * ME * MP * gamma)
    return ne * 2 * math.pi * RE**2 * ME / (MP * (gamma - 1)) * (
        gamma**2 / (gamma**2 - 1) - q / qm + (gamma - 1) / (2 * (gamma + 1)) * q**2
    ) / q**2 / energy


def low_limit(target, energy, variant):
    p, beta2, ee, maximum, printed, width, center, reduction, distortion, logs, _ = terms(
        target, energy, variant
    )
    shape0 = 1 / (center**2 + width**2) - reduction / (p.t1**2 + p.gamma1_fixed**2)
    if variant == "printed":
        hard0 = 1 / (4 * (energy + 2 * MP)**2) - 1 / (
            (printed + p.thresholds + p.delta) * p.thresholds
        )
    else:
        hard0 = 1 / (2 * (energy + MP)**2) - beta2 / (
            (maximum + p.thresholds) * p.thresholds
        )
    value = distortion / ee * np.sum(p.fractions * (
        p.k * width**2 * logs * shape0 + p.ne * PI_E4 * hard0
    ))
    return value


def main():
    variants = ("printed", "corrected", "refit")
    for energy in (1e6, 10e6, 100e6, 800e6, 1e9, 2e9):
        _, beta2, ee, maximum, printed = state(energy)
        print(f"E={energy/1e6:g} MeV beta2={beta2:.8g} Ee={ee:.8g} eV "
              f"Tmax={maximum/1e3:.8g} keV printed={printed/1e3:.8g} keV")
        for target in (N2, O2):
            for variant in variants:
                *_, distortion, logs, a = terms(target, energy, variant)
                print(f"  {target.name:2s} {variant:9s} A={a:.8f} D={distortion:.8f} "
                      f"D*A={distortion*a:.8f} S(0)={low_limit(target,energy,variant):.8e}")
    print("\nExact SDCS / free Bhabha, W=T; binding-shift errors vanish in hard limit:")
    for energy, t in ((10e6, 5e3), (100e6, 50e3), (800e6, 100e3),
                      (800e6, 500e3), (800e6, 2e6)):
        for target in (N2, O2):
            print(f"E={energy/1e6:g} MeV T={t/1e3:g} keV {target.name}", end=" ")
            for variant in variants:
                cut = state(energy)[4 if variant == "printed" else 3]
                ratio = sdcs(target, energy, t, variant) / bhabha(target.ne, energy, t)
                print(f"{variant}={ratio:.8f}" if t <= cut else f"{variant}=outside", end=" ")
            print()
    print("\nAssertions:")
    for target in (N2, O2):
        for energy in (1e6, 10e6, 100e6, 800e6):
            for fraction in (.001, .1, .9):
                t = state(energy)[3] * fraction
                np.testing.assert_allclose(bhabha(target.ne,energy,t),
                                           bhabha_q(target.ne,energy,t), rtol=1e-11)
            for variant in variants:
                limit = low_limit(target, energy, variant)
                np.testing.assert_allclose(sdcs(target,energy,1e-9,variant),limit,rtol=1e-9)
                p, beta2, ee, maximum, printed, width, center, b, d, logs, a = terms(target,energy,variant)
                t = 1e12
                soft_coefficient = p.k*width**2*(p.fractions @ logs)*t**2*soft_shape(t,width,center,p,b)
                np.testing.assert_allclose(soft_coefficient,p.ne*PI_E4*a,rtol=1e-9)
    print("PASS: Bhabha q-to-W transformation, analytic T=0 limit, soft-tail coefficient")
    print("\nPrinted N2 negative-tail example:")
    energy = 800e6
    cut = state(energy)[4]
    zero = brentq(lambda t: sdcs(N2,energy,t,"printed"), .7*cut, cut)
    print(f"zero={zero/1e3:.8f} keV; cutoff={cut/1e3:.8f} keV; "
          f"S(cutoff)={sdcs(N2,energy,cut,'printed'):.8e}")
    print("\nFirst corrected/refit endpoint zeros in 0.8--5 GeV:")
    for target in (N2,O2):
        for variant in ("corrected", "refit"):
            fun = lambda e: sdcs(target,e,state(e)[3],variant)
            grid = np.geomspace(800e6,5e9,200)
            for lower,upper in zip(grid[:-1],grid[1:]):
                if fun(lower)*fun(upper)<0:
                    root=brentq(fun,lower,upper)
                    print(target.name,variant,f"E={root/1e9:.9g} GeV")
    print("\nLow-secondary positivity, 1 keV--1 GeV projectile grid:")
    for target in (N2,O2):
        for variant in variants:
            energies=np.geomspace(1e3,1e9,2001)
            vals=np.array([low_limit(target,e,variant) for e in energies])
            print(target.name,variant,"min S(0)=", vals.min(), "all positive=",bool(np.all(vals>0)))


if __name__ == "__main__":
    main()
