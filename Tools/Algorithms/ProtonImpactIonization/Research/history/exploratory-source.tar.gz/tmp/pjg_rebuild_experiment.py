"""Exploratory reconstruction, not a validated production cross section.

Energies are in eV and cross sections in cm^2. The local GLOW reference
tables are used only as a diagnostic of the ionization dipole coefficient.
They are not redistributed with WarpX. Rudd's recommended spectra are
model curves, not independent experimental samples.
"""

from pathlib import Path
import json

import numpy as np
from scipy.integrate import simpson
from scipy.optimize import least_squares
from scipy.special import expit

ME = 510998.95069
MP = 938272088.16
RY = 13.605693122994
A0 = 5.29177210544e-9
ALPHA = 7.2973525643e-3
CB = 4 * np.pi * A0**2 * RY**2
PHOTO_FACTOR = 4 * np.pi**2 * ALPHA * A0**2 * RY
ROOT = Path(__file__).resolve().parent
ORBITALS = {
    "N2": (np.array([15.59, 16.96, 18.78, 37.3, 409.9, 409.9]),
           np.array([2, 4, 2, 2, 2, 2])),
    "O2": (np.array([12.07, 16.42, 18.88, 25.69, 40.3, 543.5, 543.5]),
           np.array([2, 2, 4, 2, 2, 2, 2])),
}
RUDD = {
    "N2": np.array([1.05, 12, .74, -.39, .80, .95, 1.20, 1, 1.30, .70]),
    "O2": np.array([1.02, 50, .40, .12, .30, 1, 5, .55, 0, .59]),
    "inner": np.array([1.25, .5, 1, 1, 3, 1.1, 1.3, 1, 0, .66]),
}


def kinematics(energy):
    u = np.asarray(energy) / MP
    bg2 = u * (u + 2)
    gamma = 1 + u
    beta2 = bg2 / gamma**2
    maximum = 2 * ME * bg2 / (1 + 2 * gamma * ME / MP + (ME / MP)**2)
    return beta2, gamma, ME * beta2 / 2, maximum


def rudd_total(target, energy):
    a, b, c, d = {"N2": (3.82, 2.78, 1.8, .70), "O2": (4.77, 0, 1.76, .93)}[target]
    u = np.asarray(energy) * ME / MP / RY
    return 4 * np.pi * A0**2 / (u / (a * np.log1p(u) + b) + 1 / (c * u**d))


def rudd_sdcs(target, energy, secondary):
    thresholds, occupation = ORBITALS[target]
    secondary = np.asarray(secondary)
    result = np.zeros_like(secondary)
    for threshold, n in zip(thresholds, occupation, strict=True):
        p = RUDD["inner" if threshold > 2 * thresholds[0] else target]
        a1, b1, c1, d1, e1, a2, b2, c2, d2, alpha = p
        v = np.sqrt(energy * ME / MP / threshold)
        w = secondary / threshold
        h1 = a1 * np.log1p(v**2) / (v**2 + b1 / v**2)
        l1 = c1 * v**d1 / (1 + e1 * v**(d1 + 4))
        h2 = a2 / v**2 + b2 / v**4
        l2 = c2 * v**d2
        wc = 4 * v**2 - 2 * v - RY / (4 * threshold)
        result += (CB * n / threshold**3 * (h1 + l1 + h2 * l2 / (h2 + l2) * w)
                   / (1 + w)**3 * expit(-alpha * (w - wc) / v))
    return result


class GlowDipole:
    """Use the GLOW state-branching/ionization tables for diagnostics only.

    Broad dissociative states use GLOW's effective thresholds. A 200 eV
    boundary avoids treating its high-energy Auger yield as valence electrons.
    The power-law continuation is a modeling assumption, not measured data.
    """

    def __init__(self, target):
        a = np.loadtxt(ROOT / f"ephoto_x{target.lower()}.dat", skiprows=4)[::-1]
        self.thresholds = {"N2": [15.60, 16.70, 18.80, 30, 34.80, 25],
                           "O2": [12.07, 16.10, 18.20, 20]}[target]
        self.energy = 12398.41984332 / ((a[:, 0] + a[:, 1]) / 2)
        probabilities = a[:, 2:8]
        # Rounded tabulations need normalization before forming partials.
        sums = probabilities.sum(axis=1)
        probabilities = np.divide(probabilities, sums[:, None],
                                  out=np.zeros_like(probabilities), where=sums[:, None] > 0)
        self.strengths = probabilities * a[:, 8, None] * 1.e-18 / PHOTO_FACTOR

    def partial(self, energy, channel):
        bounded = np.minimum(energy, 200.)
        value = np.interp(bounded, self.energy, self.strengths[:, channel], left=0)
        return value * (bounded / energy)**3.5

    def __call__(self, secondary):
        result = np.zeros_like(np.asarray(secondary), dtype=float)
        for channel, threshold in enumerate(self.thresholds):
            w = np.asarray(secondary) + threshold
            result += self.partial(w, channel) / w
        return result


class KimDipole:
    """Rudd (1992), Table II: N2, with an explicit diagnostic tail join."""

    def __init__(self):
        self.thresholds = [15.59, 28.8, 410.]
        self.coefficients = [
            [(5.5,.465,.155,0),(.8,.59,.035,0),(3.4,.71,.14,0),
             (1.3,.81,.09,0),(1.6,.26,.08,0),(10,.11,.1,1.1)],
            [(1.6,.26,.06,0),(.7,.36,.055,0),(.5,.525,.02,2),
             (.5,.47,.08,1),(.6,.12,.08,.1),(.4,.18,.05,1)],
        ]

    def partial_raw(self, energy, channel):
        r = RY / energy
        if channel == 2:
            edf = 2.99*r + 5813*r**2 + 30506*r**3 - 1987000*r**4
        else:
            edf = sum(a*np.exp(-((r-b)/c)**2)*r**d
                      for a,b,c,d in self.coefficients[channel])
        return edf / energy

    def partial(self, energy, channel):
        boundary = 200. if channel < 2 else 2000.
        bounded = np.minimum(energy, boundary)
        return self.partial_raw(bounded, channel) * (bounded / energy)**3.5

    def __call__(self, secondary):
        result = np.zeros_like(np.asarray(secondary), dtype=float)
        for channel, threshold in enumerate(self.thresholds):
            w = np.asarray(secondary) + threshold
            result += self.partial(w, channel) / w
        return result


def sdcs(target, energy, secondary, dipole, parameters):
    """Positive exploratory hard + dipole form; three collision parameters.

    J, p, and c replace the printed distortion and Bethe scales. They do not
    constitute an exact finite-energy PWBA calculation. The hard term is the
    entire Bhabha bracket multiplied by a positive bound-electron factor.
    """
    j, power, c = parameters
    t = np.asarray(secondary)
    beta2, gamma, ee, maximum = kinematics(energy)
    thresholds, occupation = ORBITALS[target]
    hard_nr = np.sum(occupation / (t[..., None] + thresholds)**2, axis=-1)
    # This form preserves the relative endpoint cancellation of the *whole*
    # free-electron cross section, instead of shifting its terms separately.
    qfactor = ((1 - t / maximum) + t / maximum / gamma**2
               + .5 * (t / (energy + MP))**2)
    hard = hard_nr * qfactor
    log_x = np.log(c * ee) + 2 * np.log(gamma)
    log_factor = np.logaddexp(0., log_x) - beta2 * expit(log_x)
    # The nonrelativistic equivalent kinetic energy is unbounded, unlike ee.
    ek = energy * ME / MP
    d_soft = expit(power * np.log(ek / j))
    d_hard = d_soft
    result = CB / ee * (d_hard * hard + d_soft * dipole(t) * log_factor)
    return np.where((t >= 0) & (t <= maximum), result, 0)


def totals(target, energies, dipole, parameters):
    return np.array([total(target, energy, dipole, parameters) for energy in energies])


def total(target, energy, dipole, parameters):
    maximum = kinematics(energy)[3]
    x = np.linspace(0, np.log1p(maximum), 2001)
    t = np.expm1(x)
    t[-1] = maximum
    return simpson(sdcs(target, energy, t, dipole, parameters) * np.exp(x), x=x)


def main():
    for target in ("N2", "O2"):
        for provider in ([KimDipole(), GlowDipole(target)] if target == "N2" else [GlowDipole(target)]):
            energies = np.geomspace(5.e3, 4.e6, 31)
            expected = rudd_total(target, energies)
            spectra_energy = (50.e3, 100.e3, 300.e3, 1.e6)
            t = np.geomspace(2, 100, 20)
            expected_spectra = [rudd_sdcs(target, e, t) for e in spectra_energy]

            def residual(log_parameters):
                parameters = np.exp(log_parameters)
                r = np.log(totals(target, energies, provider, parameters) / expected)
                spectrum = np.concatenate([np.log(sdcs(target, e, t, provider, parameters) / y)
                                           for e,y in zip(spectra_energy, expected_spectra, strict=True)])
                return np.concatenate((r / np.sqrt(len(r)), spectrum / np.sqrt(len(spectrum))))

            fit = least_squares(residual, np.log([40, 1, .1]),
                                bounds=(np.log([.01,.1,1.e-5]),np.log([1.e5,5,1.e3])))
            parameters = np.exp(fit.x)
            fitted = totals(target, energies, provider, parameters)
            print(target, type(provider).__name__, parameters, "rms log", np.linalg.norm(fit.fun),
                  "total ratio range", np.min(fitted/expected), np.max(fitted/expected))
            for e in (5.e3, 50.e3, 100.e3, 1.e6, 800.e6):
                print(e, "total", total(target, e, provider, parameters), "sdcs",
                      sdcs(target, e, np.array([0,2,10,100]), provider, parameters))
            result = {"parameters": parameters.tolist(), "energies": energies.tolist(),
                      "totals": fitted.tolist(), "rudd_totals": expected.tolist()}
            (ROOT / f"rebuild-{target}-{type(provider).__name__}.json").write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
