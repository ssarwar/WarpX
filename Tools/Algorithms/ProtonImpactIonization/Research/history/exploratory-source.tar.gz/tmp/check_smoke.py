from pathlib import Path

import numpy as np
from openpmd_viewer import OpenPMDTimeSeries

from pjg_reference import N2, kinematics, sdcs


ts = OpenPMDTimeSeries("pjg_smoke_800_tail_run/diags/diag1")
w, ux, uy, uz = ts.get_particle(
    ["w", "ux", "uy", "uz"], species="electrons", iteration=1
)
u2 = ux**2 + uy**2 + uz**2
energy = 510_998.95069 * (np.sqrt(1.0 + u2) - 1.0)

tmax = kinematics(800.0e6)[3]
x = np.linspace(0.0, np.log1p(tmax), 1_000_000)
t = np.expm1(x)
pdf_x = sdcs(N2, 800.0e6, t) * (t + 1.0)
cdf = np.zeros_like(t)
cdf[1:] = np.cumsum(0.5 * (pdf_x[:-1] + pdf_x[1:]) * np.diff(x))
cdf /= cdf[-1]

quantiles = np.array([0.001, 0.01, 0.1, 0.5, 0.9, 0.99, 0.999, 0.9999])
expected = np.interp(quantiles, cdf, t)
observed = np.quantile(energy, quantiles)
print("q expected observed ratio")
for q, exact, sampled in zip(quantiles, expected, observed):
    print(q, exact, sampled, sampled / exact)
print("max", energy.max(), tmax)
print("mean", energy.mean(), np.trapezoid(t * pdf_x, x) / np.trapezoid(pdf_x, x))
print("forward", np.mean(uz / np.sqrt(u2)), "transverse", np.mean(ux), np.mean(uy))
