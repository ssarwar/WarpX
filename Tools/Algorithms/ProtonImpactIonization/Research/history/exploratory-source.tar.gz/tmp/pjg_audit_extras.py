"""Moment sensitivity and angular-closure diagnostics for the PJG audit."""

import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq

from pjg_consistency_audit import continuum, moments
from pjg_limit_audit import N2, O2, ME, MP, PI_E4, state, sdcs, bhabha


def hard_moments(target,energy,lower,upper):
    _,b2,ee,cut,_=state(energy)
    constant=1/(2*(energy+MP)**2)
    def primitive(u):
        return np.array([-1/u-b2/cut*math.log(u)+constant*u,
                         math.log(u)-b2/cut*u+constant*u*u/2,
                         u-b2/cut*u*u/2+constant*u**3/3])
    return target.ne*PI_E4/ee*(primitive(upper)-primitive(lower))


result={}
for target in (N2,O2):
    e=800e6
    cut=state(e)[3]
    original=moments(target,e)
    difference=hard_moments(target,e,100e3,cut)-(original-moments(target,e,100e3))
    # Diagnostic replacement above 100 keV, not a proposed physical splice.
    changed=original+difference
    data={"replace_above_100_keV_diagnostic": {
        "total_relative_change":float(changed[0]/original[0]-1),
        "mean_relative_change":float((changed[1]/changed[0])/(original[1]/original[0])-1),
        "second_moment_relative_change":float((changed[2]/changed[0])/(original[2]/original[0])-1)}}
    angular={}
    for e in (1e3,50e3,800e6):
        cut=state(e)[3]
        sigma=moments(target,e)[0]
        def shape(t):
            c=continuum(target,e,t)
            binding=np.sum(c*target.thresholds)/np.sum(c)
            free=np.sqrt(t*(cut+2*ME)/(cut*(t+2*ME)))
            b=binding/(t+binding)
            a=free*(1-b/2)
            return a,b
        def integrand(x):
            t=np.expm1(x)
            a,b=shape(t)
            forward_atom=np.clip((a+b-1)/(2*b),0,1)
            return float(sdcs(target,e,t,"refit"))*np.exp(x)/sigma*forward_atom
        def sign(t):
            a,b=shape(t)
            return a+b-1
        probe=np.geomspace(1e-14,cut,4097)
        roots=[0.]
        for lower,upper in zip(probe[:-1],probe[1:]):
            if sign(lower)*sign(upper)<0:
                roots.append(brentq(sign,lower,upper,xtol=1e-13))
        roots.append(cut)
        angular[str(e)]=sum(quad(integrand,np.log1p(lower),np.log1p(upper),
                                epsabs=1e-13,epsrel=1e-9,limit=400)[0]
                            for lower,upper in zip(roots[:-1],roots[1:]))
    data["angular_forward_atom_probability"]=angular
    result[target.name]=data

fig,axes=plt.subplots(1,2,figsize=(10.8,4.3),sharex=True,sharey=True,layout="constrained")
energy=800e6
for ax,target in zip(axes,(N2,O2)):
    exact,printed=state(energy)[3:]
    for variant,color,style in (("printed","#d97706","-"),("corrected","#2563eb","--"),
                                 ("refit","#059669","-")):
        upper=printed if variant=="printed" else exact
        t=np.geomspace(1e4,upper,1000)
        ratio=sdcs(target,energy,t,variant)/bhabha(target.ne,energy,t)
        label={"printed":"Printed + 1977 errata","corrected":"Corrected, before refit",
               "refit":"Current corrected/refit"}[variant]
        ax.semilogx(t/1e3,ratio,color=color,linestyle=style,label=label,lw=1.8)
    ax.axhline(1,color="#475569",lw=.8)
    ax.axhline(0,color="#94a3b8",lw=.7)
    ax.set_title(target.name+": 800 MeV protons")
    ax.set_xlabel("Secondary kinetic energy T (keV)")
    ax.set_ylim(-.25,1.7)
    ax.grid(alpha=.18)
axes[0].set_ylabel("PJG SDCS / free-electron Bhabha SDCS")
axes[1].legend(fontsize=8,loc="lower left")
fig.savefig("tmp/pjg_hard_tail_audit.png",dpi=175)
plt.close(fig)
Path("tmp/pjg_audit_extras_results.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
