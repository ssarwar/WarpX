import math
from dataclasses import dataclass

import numpy as np


ME = 510_998.95069
MP = 938_272_088.16
RE_CM = 2.817_940_3205e-13
PI_E4 = math.pi * (RE_CM * ME) ** 2


@dataclass(frozen=True)
class Target:
    name: str
    ne: int
    b0: float
    b1: float
    e0: float
    t1: float
    gamma1_fixed: float
    k: float
    gamma_s: float
    gamma_1: float
    gamma_2: float
    t_s: float
    t_a: float
    t_b: float
    j: float
    nu: float
    delta: float
    thresholds: np.ndarray
    fractions: np.ndarray
    c: np.ndarray


N2 = Target(
    "N2",
    14,
    0.029,
    1.035,
    8239.0,
    53.3,
    115.0,
    7.58e-16,
    11.1,
    1.27e4,
    1.81e3,
    4.0,
    2.03e4,
    1.97e3,
    3.39,
    -1.93e-1,
    84.0,
    np.array([15.58, 16.73, 18.75, 22.0, 23.6, 40.0]),
    np.array([0.456, 0.2, 0.104, 0.07, 0.07, 0.1]),
    np.array([2.48, 2.66, 2.99, 3.50, 3.76, 6.37]),
)

O2 = Target(
    "O2",
    16,
    0.030,
    1.035,
    8239.0,
    68.3,
    189.1,
    6.55e-16,
    13.1,
    5.0e5,
    7.60e4,
    6.34,
    2.52e3,
    1.28e2,
    40.3,
    3.14e-1,
    132.1,
    np.array([12.1, 16.1, 16.9, 18.2, 20.3, 23.0, 37.0]),
    np.array([0.08, 0.19, 0.19, 0.17, 0.11, 0.16, 0.1]),
    np.array([1.93, 2.56, 2.69, 2.90, 3.23, 3.66, 5.89]),
)


def kinematics(kinetic_energy, projectile_rest_energy=MP):
    gamma = 1.0 + kinetic_energy / projectile_rest_energy
    beta2 = 1.0 - 1.0 / gamma**2
    equivalent_energy = 0.5 * ME * beta2
    mass_ratio = ME / projectile_rest_energy
    tmax = (
        2.0 * ME * beta2 * gamma**2
        / (1.0 + 2.0 * gamma * mass_ratio + mass_ratio**2)
    )
    return gamma, beta2, equivalent_energy, tmax


def pjg_printed_tmax(kinetic_energy, projectile_rest_energy=MP):
    return kinetic_energy * (kinetic_energy + 2.0 * projectile_rest_energy) / (
        kinetic_energy
        + ME
        + (projectile_rest_energy / ME)
        * (kinetic_energy + projectile_rest_energy)
    )


def sdcs(target, kinetic_energy, secondary_energy, correction="bhabha"):
    total_projectile_energy = kinetic_energy + MP
    _, beta2, ee, tmax = kinematics(kinetic_energy)
    gamma_width = target.gamma_1 / (ee + target.gamma_2) + target.gamma_s
    t0 = target.t_s - target.t_a / (ee + target.t_b)
    b = target.b0 * (math.log(ee / target.e0) ** 2 + target.b1)
    power = target.nu + 1.0
    distortion = ee**power / (target.j**power + ee**power)
    t = np.asarray(secondary_energy)
    result = np.zeros_like(t, dtype=float)
    shape = 1.0 / ((t - t0) ** 2 + gamma_width**2) - b / (
        (t - target.t1) ** 2 + target.gamma1_fixed**2
    )
    for threshold, fraction, c in zip(
        target.thresholds, target.fractions, target.c, strict=True
    ):
        fj = fraction * distortion
        bethe = target.k * gamma_width**2 * (
            math.log(
                4.0 * ee * c / (threshold * (1.0 - beta2)) + math.e
            )
            - beta2
        )
        if correction == "none":
            hard = 0.0
        elif correction == "printed":
            hard = target.ne * PI_E4 * (
                1.0 / (4.0 * (kinetic_energy + 2.0 * MP) ** 2)
                - 1.0 / ((tmax + threshold + target.delta) * (t + threshold))
            )
        elif correction == "bhabha":
            hard = target.ne * PI_E4 * (
                1.0 / (2.0 * total_projectile_energy**2)
                - beta2
                / ((tmax + threshold + target.delta) * (t + threshold))
            )
        else:
            raise ValueError(correction)
        result += fj / ee * (bethe * shape + hard)
    return result


def integrate(target, kinetic_energy, correction="bhabha", points=300_000):
    tmax = kinematics(kinetic_energy)[3]
    scale = 1.0
    x = np.linspace(0.0, math.log1p(tmax / scale), points)
    t = scale * np.expm1(x)
    y = sdcs(target, kinetic_energy, t, correction=correction)
    sigma = np.trapezoid(y * (t + scale), x)
    return sigma, y.min(), t[np.argmin(y)], tmax


def main():
    print(f"pi e^4 = {PI_E4:.12e} eV^2 cm^2")
    for energy in (50e3, 200e3, 500e3, 1e6, 10e6, 100e6, 800e6):
        _, beta2, ee, tmax = kinematics(energy)
        old_tmax = pjg_printed_tmax(energy)
        print(
            f"E={energy:10.3e} beta2={beta2:.8f} Ee={ee:.6g} "
            f"Tmax={tmax:.6g} old={old_tmax:.6g} ratio={tmax/old_tmax:.6g}"
        )
        for target in (N2, O2):
            sigma, minimum, t_at_min, _ = integrate(target, energy)
            values = sdcs(target, energy, np.array([0.0, 1.0, 10.0, 100.0]))
            formatted = ", ".join(f"{v * 1e16:.6g}" for v in values)
            print(
                f"  {target.name} sigma={sigma * 1e16:.8g}e-16 cm2 "
                f"min={minimum:.3e}@{t_at_min:.4g}; S*1e16=[{formatted}]"
            )


if __name__ == "__main__":
    main()
