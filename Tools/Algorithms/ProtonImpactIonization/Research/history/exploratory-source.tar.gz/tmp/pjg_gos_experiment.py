"""Diagnostic matched optical PWBA + complete Bhabha model, not production.

Optical providers have the limitations documented in pjg_rebuild_experiment.
No experimental data points are manufactured from Rudd's recommended curves.
"""

import json
from pathlib import Path

import numpy as np
from scipy.integrate import simpson
from scipy.optimize import least_squares
from scipy.special import expit

from pjg_rebuild_experiment import (
    CB, ME, MP, ORBITALS, GlowDipole, KimDipole, kinematics, rudd_sdcs, rudd_total,
)


def molecular_maximum(target, energy, binding):
    a = {"N2": 28.0134, "O2": 31.9988}[target] * 931494103.72
    threshold = binding * (1 + MP / a) + binding**2 / (2 * a)
    root_s = np.sqrt((MP + a)**2 + 2 * a * energy)
    excess = 2 * a * np.maximum(energy - threshold, 0) / (root_s + MP + a + binding)
    kinetic = excess * (1 - (ME + excess / 2) / root_s)
    p2 = energy * (energy + 2 * MP)
    gm1 = p2 / (root_s * (energy + MP + a + root_s))
    return np.where(energy >= threshold, kinetic + gm1 * (kinetic + ME)
                    + np.sqrt(p2) / root_s * np.sqrt(kinetic * (kinetic + 2 * ME)), 0)


def pwba_grid(energy, loss, nodes=96):
    """Positive Eq. (68) kernel, integrated in log(q^2-W^2), c=1.

    Return Q and quadrature weights for dimensionless W times the integral.
    Equal longitudinal/transverse GOS is the optical approximation in Salvat
    and Heredia; this is not used as a substitute for the hard Dirac trace.
    """
    energy, loss = np.broadcast_arrays(energy, loss)
    p2 = energy * (energy + 2 * MP)
    p = np.sqrt(p2)
    pf = np.sqrt((energy - loss) * (energy - loss + 2 * MP))
    total = energy + MP
    qminus = loss * (2 * total - loss) / (p + pf)
    # Rationalized lower light-cone separation, even when gamma >> 1.
    ymin = (MP / (total + p)) * (MP / (total - loss + pf)) * (qminus + loss)**2
    ymax = (p + pf - loss) * (p + pf + loss)
    x, weight = np.polynomial.legendre.leggauss(nodes)
    span = np.log(ymax / ymin)
    y = ymin[..., None] * np.exp(span[..., None] * (x + 1) / 2)
    z = y + loss[..., None]**2
    recoil = z / (np.sqrt(z + ME**2) + ME)
    sin2 = ((y - ymin[..., None]) / z) * ((ymax[..., None] - y) / (4 * p2[..., None]))
    beta2 = kinematics(energy)[0]
    jacobian = ME / np.sqrt(z + ME**2) * y * span[..., None] * weight / 2
    longitudinal = jacobian / z
    transverse = jacobian * beta2[..., None] * sin2 * (loss[..., None] / y)**2
    return recoil, longitudinal, transverse


class Batch:
    def __init__(self, target, energy, secondary, dipole, nodes=96):
        self.energy, self.secondary = np.broadcast_arrays(energy, secondary)
        self.target = target
        self.ek = self.energy * ME / MP
        beta2, gamma, ee, maximum = kinematics(self.energy)
        self.prefactor = CB / ee
        thresholds, occupation = ORBITALS[target]
        loss = self.secondary[..., None] + thresholds
        fraction = loss / maximum[..., None]
        factor = 1 - fraction + fraction / gamma[..., None]**2
        factor += .5 * (loss / (self.energy[..., None] + MP))**2
        self.hard = np.where(loss <= maximum[..., None], occupation / loss**2 * factor, 0)
        self.hard_scale = self.secondary[..., None] / thresholds
        self.soft = []
        for channel, threshold in enumerate(dipole.thresholds):
            loss = self.secondary + threshold
            valid = self.secondary < molecular_maximum(target, self.energy, threshold)
            # Dummy, valid loss for excluded cells; their weights are zero.
            bounded_loss = np.where(valid, loss, .5 * self.energy)
            q, kl, kt = pwba_grid(self.energy, bounded_loss, nodes)
            optical = np.where(valid, dipole.partial(loss, channel) / loss, 0)
            self.soft.append((np.maximum(q / threshold - 1, 0),
                              (kl + kt) * optical[..., None]))

    def parts(self, parameters):
        j, power, b = parameters
        soft = sum(np.sum(kernel / (1 + scale / b)**2, axis=-1)
                   for scale, kernel in self.soft)
        hard = np.sum(self.hard * (1 - 1 / (1 + self.hard_scale / b)**2), axis=-1)
        distortion = expit(power * np.log(self.ek / j))
        return self.prefactor * hard, self.prefactor * distortion * soft

    def __call__(self, parameters):
        hard, soft = self.parts(parameters)
        return hard + soft


def main():
    for target, dipole in (("N2", KimDipole()), ("O2", GlowDipole("O2"))):
        energies = np.geomspace(5.e3, 4.e6, 31)
        maximum = molecular_maximum(target, energies, min(dipole.thresholds))
        x = np.linspace(0, 1, 769)[None, :] * np.log1p(maximum[:, None])
        t = np.expm1(x)
        grid = Batch(target, energies[:, None], t, dipole)
        target_total = rudd_total(target, energies)
        spectra_energy = ([5.e3, 10.e3, 50.e3, 100.e3, 300.e3, 1.e6]
                          if target == "N2" else [7.5e3, 10.e3, 50.e3, 100.e3, 300.e3])
        sample_energy, sample_secondary, target_spectrum = [], [], []
        for energy in spectra_energy:
            t = np.geomspace(2, min(2 * kinematics(energy)[3], 3000), 48)
            spectrum = rudd_sdcs(target, energy, t)
            keep = spectrum > spectrum[0] * 1.e-4
            sample_energy.extend([energy] * np.count_nonzero(keep))
            sample_secondary.extend(t[keep])
            target_spectrum.extend(spectrum[keep])
        spectral_grid = Batch(target, sample_energy, sample_secondary, dipole)
        target_spectrum = np.array(target_spectrum)

        def residual(log_parameters):
            parameters = np.exp(log_parameters)
            total = simpson(grid(parameters) * np.exp(x), x=x, axis=-1)
            r_total = np.log(total / target_total)
            r_spectrum = np.log(spectral_grid(parameters) / target_spectrum)
            return np.concatenate((r_total / np.sqrt(len(r_total)),
                                   r_spectrum / np.sqrt(len(r_spectrum))))

        fit = least_squares(residual, np.log([40, 1, 4]),
                            bounds=(np.log([.1,.1,.01]), np.log([1.e4,5,100])),
                            max_nfev=100)
        parameters = np.exp(fit.x)
        total = simpson(grid(parameters) * np.exp(x), x=x, axis=-1)
        ratio = spectral_grid(parameters) / target_spectrum
        print(target, parameters, "rms log", np.linalg.norm(fit.fun),
              "total ratio", np.min(total/target_total), np.max(total/target_total),
              "sdcs ratios", np.percentile(ratio, [0,10,50,90,100]), flush=True)
        tail_mask = grid.secondary > kinematics(grid.energy)[3]
        tail = simpson(np.where(tail_mask, grid(parameters), 0) * np.exp(x), x=x, axis=-1) / total
        print("Tail fractions", list(zip(energies[:8], tail[:8])), flush=True)
        result = {"parameters": parameters.tolist(), "energies": energies.tolist(),
                  "totals": total.tolist(), "rudd_totals": target_total.tolist(),
                  "tail_fractions": tail.tolist(), "sdcs_energy": sample_energy,
                  "sdcs_secondary": np.array(sample_secondary).tolist(),
                  "sdcs_ratio": ratio.tolist()}
        (Path(__file__).resolve().parent / f"gos-{target}.json").write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
