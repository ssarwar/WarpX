# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Optical/stopping tradeoffs without extra independent SDCS parameters.

The unchanged six-parameter reference is retained as the baseline. Trials
either reweight its optical residual or fix the T_a multiplier and instead
refit PJG's existing T_s. Neither changes the selected production model.
The O2 optical input and NIST text tables are external source files.
"""

import argparse
import json
from dataclasses import asdict, astuple, replace
from pathlib import Path

import numpy as np
from fit_pjg_matched import FitProblem, o2_photoelectron_coefficient
from fit_pjg_optical import n2_photoelectron_coefficient
from pjg_matched import SELECTED_PARAMETERS, MatchedParameters, optical_coefficient
from pjg_repair import TARGETS
from scipy.optimize import least_squares, minimize
from stopping_pjg_matched import LossGrid, load_pstar, mass_stopping, optical_strength


def fit_peak(problem, initial, pstar=None):
    """Exchange the free T_a multiplier for free T_s: still six fitted quantities."""
    defaults = np.array(astuple(replace(initial, center_scale=1)))
    active = np.array([0, 2, 3, 4, 8])
    lower = np.r_[np.log([0.01, 0.01, 0.1, 1, 0.25]), -5]
    upper = np.r_[np.log([1e5, 10, 100, 1000, 4]), 5]

    def unpack(values):
        parameters = defaults.copy()
        parameters[active] = np.exp(values[:-1])
        return MatchedParameters(*parameters), 10 * values[-1]

    result = least_squares(
        lambda values: problem.residual(*unpack(values)),
        np.r_[np.log(defaults[active]), TARGETS[problem.target].center_s / 10],
        bounds=(lower, upper),
        max_nfev=600,
        ftol=1e-10,
        xtol=1e-10,
        gtol=1e-9,
    )
    if not result.success:
        raise RuntimeError(result.message)
    if pstar is not None:
        keep = pstar.energies >= 5000
        losses = LossGrid(problem.target, pstar.energies[keep], points=257)

        def budget(values):
            moments = losses(*unpack(values))
            return (
                1
                - mass_stopping(problem.target, moments.ionization)
                / pstar.electronic[keep]
            )

        # A necessary upper budget, not a target for fitting ionization to
        # total electronic stopping. No excitation fraction is guessed here.
        def objective(values):
            residual = problem.residual(*unpack(values))
            return np.dot(residual, residual)

        result = minimize(
            objective,
            result.x,
            method="SLSQP",
            bounds=list(zip(lower, upper, strict=True)),
            constraints={"type": "ineq", "fun": budget},
            options={"maxiter": 300, "ftol": 1e-12},
        )
        if not result.success:
            raise RuntimeError(result.message)
    return unpack(result.x)


def summarize(problem, parameters, peak, losses, electronic):
    total, _ = problem.moments(parameters, center_s=peak)
    optical = (
        optical_coefficient(
            problem.target, problem.optical_t, parameters, center_s=peak
        )
        / problem.optical_reference
    )
    spectra = problem.spectra(parameters, center_s=peak) / problem.spectral_reference
    moments = losses(parameters, peak)
    ratio = mass_stopping(problem.target, moments.ionization) / electronic
    i = np.argmax(ratio)
    return {
        "parameters": asdict(parameters),
        "center_s": peak,
        "optical_ratio_range": [float(optical.min()), float(optical.max())],
        "optical_log_rms": float(np.sqrt(np.mean(np.log(optical) ** 2))),
        "total_ratio_range": [
            float((total / problem.total_reference).min()),
            float((total / problem.total_reference).max()),
        ],
        "sdcs_log_rms": float(np.sqrt(np.mean(np.log(spectra) ** 2))),
        "maximum_pair_to_pstar": float(ratio[i]),
        "maximum_energy_eV": float(losses.energies[i]),
        "optical_strength": float(optical_strength(problem.target, parameters, peak)),
    }


def figures(results, directory, o2_optical, pstar_paths=None):
    """Plot reference comparisons; these are not validation confidence bands."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.dpi": 170,
        }
    )
    candidates = {"N2": "weight_2", "O2": "budget_peak_2"}
    labels = {"N2": "Optical-reweighted trial", "O2": "Peak-swap + budget trial"}
    colors = {"baseline": "#7e7e7e", "trial": "#007f88"}
    t = np.geomspace(2, 100, 4001)
    fig, axes = plt.subplots(2, 2, figsize=(11.6, 7.3), sharex="col")
    for column, target in enumerate(TARGETS):
        reference = (
            n2_photoelectron_coefficient(t)
            if target == "N2"
            else o2_photoelectron_coefficient(t, o2_optical)
        )
        name = (
            "Rudd optical parameterization"
            if target == "N2"
            else "Coarse GLOW partial-ionization proxy"
        )
        axes[0, column].loglog(t, reference, color="#222222", lw=1.3, label=name)
        for key, color, label in (
            ("baseline", colors["baseline"], "Current baseline"),
            (candidates[target], colors["trial"], labels[target]),
        ):
            row = results[target][key]
            parameters = MatchedParameters(**row["parameters"])
            coefficient = optical_coefficient(
                target, t, parameters, center_s=row["center_s"]
            )
            axes[0, column].loglog(t, coefficient, color=color, lw=2, label=label)
            axes[1, column].semilogx(t, coefficient / reference, color=color, lw=2)
            print(
                target,
                key,
                "Dense 4001-point optical range:",
                (coefficient / reference).min(),
                (coefficient / reference).max(),
                flush=True,
            )
        axes[0, column].set_title(target)
        axes[0, column].legend(fontsize=8, loc="lower left")
        axes[1, column].axhline(1, color="#222222", lw=0.8)
        axes[1, column].set(
            xlabel="Ejected-electron energy (eV)", ylim=(0.55, 1.5), xlim=(2, 100)
        )
        for ax in axes[:, column]:
            ax.grid(alpha=0.15, which="both")
    axes[0, 0].set_ylabel(r"Optical coefficient $a(T)$ (eV$^{-2}$)")
    axes[1, 0].set_ylabel("Model / optical reference")
    fig.suptitle("Same six fitted quantities: optical tradeoffs within the PJG form")
    fig.text(
        0.5,
        0.015,
        "2–100 eV only. Threshold structure below 2 eV remains unresolved; O2 trial is not promoted.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.045, 1, 0.95))
    fig.savefig(directory / "pjg_optical_tradeoff.png")
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(11.6, 7.3), sharex="col")
    for column, target in enumerate(TARGETS):
        table = load_pstar(target, (pstar_paths or {}).get(target))
        keep = table.energies >= 5000
        energy, reference = table.energies[keep], table.electronic[keep]
        losses = LossGrid(target, energy)
        axes[0, column].loglog(
            energy / 1e6,
            reference,
            color="#222222",
            lw=1.4,
            label="NIST electronic (ionization + excitation)",
        )
        for key, color, label in (
            ("baseline", colors["baseline"], "Baseline effective-pair loss"),
            (candidates[target], colors["trial"], labels[target]),
        ):
            row = results[target][key]
            moments = losses(MatchedParameters(**row["parameters"]), row["center_s"])
            stopping = mass_stopping(target, moments.ionization)
            axes[0, column].loglog(
                energy / 1e6, stopping, color=color, lw=2, label=label
            )
            axes[1, column].semilogx(
                energy / 1e6, stopping / reference, color=color, lw=2
            )
            if key == "baseline":
                kinetic = mass_stopping(target, moments.kinetic)
                axes[0, column].loglog(
                    energy / 1e6,
                    kinetic,
                    color=color,
                    ls=":",
                    lw=1.5,
                    label="Baseline emitted-electron kinetic energy",
                )
                axes[1, column].semilogx(
                    energy / 1e6, kinetic / reference, color=color, ls=":", lw=1.5
                )
        axes[0, column].set_title(target)
        axes[0, column].legend(fontsize=8)
        axes[1, column].axhline(1, color="#a44a4a", lw=1)
        axes[1, column].set(
            xlabel="Proton kinetic energy (MeV)", xlim=(0.005, 10000), ylim=(0, 1.08)
        )
        for ax in axes[:, column]:
            ax.grid(alpha=0.15, which="both")
    axes[0, 0].set_ylabel(r"Mass stopping power (MeV cm$^2$/g)")
    axes[1, 0].set_ylabel("Model / NIST electronic stopping")
    fig.suptitle(
        "Stopping audit: an ionization source is not a complete stopping model"
    )
    fig.text(
        0.5,
        0.015,
        "O2's constrained trial touches the total-stopping budget: passing this ceiling is not full validation.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.045, 1, 0.95))
    fig.savefig(directory / "pjg_stopping_nist.png")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--o2-optical", required=True)
    parser.add_argument("--n2-pstar")
    parser.add_argument("--o2-pstar")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--read-results", type=Path)
    parser.add_argument("--figures", type=Path)
    args = parser.parse_args()
    pstar_paths = {"N2": args.n2_pstar, "O2": args.o2_pstar}
    if args.read_results:
        if not args.figures:
            parser.error("--read-results requires --figures")
        figures(
            json.loads(args.read_results.read_text()),
            args.figures,
            args.o2_optical,
            pstar_paths,
        )
        return
    results = {}
    for target in TARGETS:
        table = load_pstar(target, getattr(args, target.lower() + "_pstar"))
        keep = table.energies >= 5000
        losses = LossGrid(target, table.energies[keep])
        problem = FitProblem(target, args.o2_optical)
        initial = SELECTED_PARAMETERS[target]
        results[target] = {
            "baseline": summarize(
                problem, initial, None, losses, table.electronic[keep]
            )
        }
        for weight in (0.5, 1, 2):
            problem.optical_weight = weight
            parameters, _ = problem.fit([0, 2, 3, 4, 6, 8], initial)
            result = summarize(
                problem, parameters, None, losses, table.electronic[keep]
            )
            results[target][f"weight_{weight}"] = result
            print(target, "weight", weight, json.dumps(result), flush=True)
        for weight in (1, 2):
            problem.optical_weight = weight
            parameters, peak = fit_peak(problem, initial)
            result = summarize(
                problem, parameters, peak, losses, table.electronic[keep]
            )
            results[target][f"peak_{weight}"] = result
            print(target, "peak", weight, json.dumps(result), flush=True)
        if target == "O2":
            for weight in (1, 2):
                problem.optical_weight = weight
                parameters, peak = fit_peak(problem, initial, table)
                result = summarize(
                    problem, parameters, peak, losses, table.electronic[keep]
                )
                results[target][f"budget_peak_{weight}"] = result
                print(target, "budget peak", weight, json.dumps(result), flush=True)
    if args.output:
        args.output.write_text(json.dumps(results, indent=2) + "\n")
    if args.figures:
        figures(results, args.figures, args.o2_optical, pstar_paths)


if __name__ == "__main__":
    main()
