# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Research-only refit sensitivity to audited optical and proton sources.

The optical target here is an energy-loss response at 25--100 eV, not an
ejected-electron SDCS. Mapping the existing PJG channel allocation forward
to that observable avoids shifting an experimental total by an arbitrary
binding energy. It does not validate that allocation or resolve multiple
ionization. These are deliberately provisional comparisons, not a final
state-resolved optical calibration or promoted production coefficients.
"""

import argparse
import json
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
from experimental import (
    CROOKS_RUDD_1971_ENERGIES,
    CROOKS_RUDD_1971_TOTALS,
    RUDD_1979_N2_ENERGIES,
    RUDD_1979_N2_MEAN_ENERGIES,
    RUDD_1979_N2_TOTALS,
)
from fit_pjg_matched import FitProblem, MomentGrid
from fit_pjg_repair import spectral_grid
from optical_dataset_audit import pjg_loss_density, response_moments
from pjg_matched import SELECTED_PARAMETERS, SpectrumGrid, hard_factor, kinematics
from pjg_repair import TARGETS
from reference import BETHE_CONSTANT, rudd_total
from source_datasets import (
    PHOTO_FACTOR,
    RUDD_1983_ENERGIES,
    RUDD_1983_FITTED_TOTALS,
    OpticalTable,
    cheng_1989_figure1,
    load_leiden,
    load_mahla_o2,
    rudd_1983_uncertainty,
    source_digest,
)
from stopping_pjg_matched import LossGrid, free_second_moment, load_pstar, mass_stopping


def ratio_summary(ratio):
    ratio = np.asarray(ratio)
    return {
        "minimum": float(ratio.min()),
        "maximum": float(ratio.max()),
        "log_rms": float(np.sqrt(np.mean(np.log(ratio) ** 2))),
    }


class SourceFitProblem(FitProblem):
    """Group-weighted residuals, not independent measurements or chi-squared."""

    def __init__(self, target, optical, optical_weight=1, mean_weight=0.5):
        self.target = target
        self.hard_distortion = "fading"
        self.optical_weight = optical_weight
        # A residual-block weight, not an additional SDCS parameter or an
        # experimental inverse uncertainty. Keep the previous default.
        self.mean_weight = mean_weight
        self.energies = RUDD_1983_ENERGIES
        self.total_reference = RUDD_1983_FITTED_TOTALS[target]
        self.total_uncertainty = rudd_1983_uncertainty(self.energies)
        self.moments = MomentGrid(target, self.energies)
        se, st, self.spectral_reference = spectral_grid(target)
        self.spectra = SpectrumGrid(target, se, st)
        self.loss = np.geomspace(25, 100, 60)
        self.optical_reference = optical(self.loss) / PHOTO_FACTOR
        self.crooks = MomentGrid(target, CROOKS_RUDD_1971_ENERGIES)
        self.original_moments = (
            MomentGrid(target, RUDD_1979_N2_ENERGIES) if target == "N2" else None
        )
        self.cheng = []
        if target == "O2":
            points = cheng_1989_figure1()
            for energy in np.unique(points[:, 0]):
                group = points[points[:, 0] == energy]
                self.cheng.append(
                    (SpectrumGrid(target, energy, group[:, 1]), group[:, 2])
                )

    def residual(self, parameters, center_s=None):
        total, _ = self.moments(parameters, center_s=center_s)
        # Preserve the authors' larger low-energy uncertainty. The factor
        # 0.15 sets a relative block weight; it is not a confidence level.
        blocks = [
            np.log(total / self.total_reference)
            * 0.15
            / self.total_uncertainty
            / np.sqrt(len(total)),
            0.5
            * np.log(
                self.spectra(parameters, center_s=center_s) / self.spectral_reference
            )
            / np.sqrt(len(self.spectral_reference)),
        ]
        if self.optical_weight:
            optical = pjg_loss_density(self.target, self.loss, parameters, center_s)
            blocks.append(
                self.optical_weight
                * np.log(optical / self.optical_reference)
                / np.sqrt(len(self.loss))
            )
        crooks, _ = self.crooks(parameters, center_s=center_s)
        blocks.append(
            0.5 * np.log(crooks / CROOKS_RUDD_1971_TOTALS[self.target]) / np.sqrt(6)
        )
        if self.original_moments:
            total, mean = self.original_moments(parameters, center_s=center_s)
            blocks += [
                0.4 * np.log(total / RUDD_1979_N2_TOTALS) / np.sqrt(8),
                self.mean_weight
                * np.log(mean / RUDD_1979_N2_MEAN_ENERGIES)
                / np.sqrt(8),
            ]
        for grid, reference in self.cheng:
            residual = np.log(grid(parameters, center_s=center_s) / reference)
            # Cheng rescaled the displayed spectra to recommended totals.
            # Compare their shapes after removing one log normalization per
            # spectrum; do not count that normalization as independent data.
            blocks.append((residual - np.mean(residual)) / np.sqrt(3 * len(residual)))
        return np.concatenate(blocks)


def summarize(problem, parameters, loss_grid, pstar):
    total, _ = problem.moments(parameters)
    losses = loss_grid(parameters)
    stopping = mass_stopping(problem.target, losses.ionization) / pstar
    maximum = int(np.argmax(stopping))
    crooks, _ = problem.crooks(parameters)
    energy = 800e6
    t = np.array([1e3, 1e4, 1e5])
    _, _, equivalent, _ = kinematics(energy)
    bhabha = TARGETS[problem.target].electrons * BETHE_CONSTANT / equivalent
    bhabha = bhabha * hard_factor(energy, t) / t**2
    result = {
        "parameters": asdict(parameters),
        "objective_norm": float(np.linalg.norm(problem.residual(parameters))),
        "rudd_1983_fitted_total_ratio": ratio_summary(total / problem.total_reference),
        "rudd_1985_recommended_total_ratio": ratio_summary(
            total / rudd_total(problem.target, problem.energies)
        ),
        "crooks_1971_measured_total_ratio": ratio_summary(
            crooks / CROOKS_RUDD_1971_TOTALS[problem.target]
        ),
        "rudd_1992_formula_sdcs_ratio": ratio_summary(
            problem.spectra(parameters) / problem.spectral_reference
        ),
        "optical_fixed_channel_loss_density_ratio_25_100eV": ratio_summary(
            pjg_loss_density(problem.target, problem.loss, parameters)
            / problem.optical_reference
        ),
        "maximum_pair_to_pstar": float(stopping[maximum]),
        "maximum_pair_to_pstar_energy_eV": float(loss_grid.energies[maximum]),
        "pair_to_pstar_rows": np.c_[loss_grid.energies, stopping].tolist(),
        "hard_800MeV_T_1_10_100keV_ratio": (
            SpectrumGrid(problem.target, energy, t)(parameters) / bhabha
        ).tolist(),
        "second_moment_to_free_at_10GeV": float(
            losses.kinetic_second[-1]
            / free_second_moment(problem.target, loss_grid.energies[-1])
        ),
    }
    if problem.original_moments:
        total, mean = problem.original_moments(parameters)
        result["rudd_1979_measured_total_ratio"] = ratio_summary(
            total / RUDD_1979_N2_TOTALS
        )
        result["rudd_1979_measured_mean_energy_ratio"] = ratio_summary(
            mean / RUDD_1979_N2_MEAN_ENERGIES
        )
    result["cheng_1989_rescaled_data_ratios"] = [
        {
            "energy_eV": float(grid.energy[0]),
            "ratio": ratio_summary(grid(parameters) / reference),
            "shape_log_rms": float(np.std(np.log(grid(parameters) / reference))),
        }
        for grid, reference in problem.cheng
    ]
    return result


def audit_mahla(tables, measured):
    total = tables["total"]
    energy = total.energy
    summed = sum(
        tables[key](energy, outside="zero") for key in ("pi_g", "pi_u", "sigma_g")
    )
    ratio = summed / total.cross_section_Mb
    index = int(np.argmin(ratio))
    return {
        "grouped_tables": {key: len(value.energy) for key, value in tables.items()},
        "threshold_raw_eV": float(energy[0]),
        "threshold_nist_eV": 12.0697,
        "subthreshold_integral_Mb_eV": total.integrate(energy[0], 12.0697),
        "subthreshold_fraction_of_10p993_40eV_integral": (
            total.integrate(energy[0], 12.0697) / total.integrate(energy[0], 40)
        ),
        "minimum_partial_sum_over_total": float(ratio[index]),
        "minimum_partial_sum_energy_eV": float(energy[index]),
        "partial_sum_and_total_at_minimum_Mb": [
            float(summed[index]),
            float(total.cross_section_Mb[index]),
        ],
        "integrated_cross_section_ratios_to_leiden": [
            {
                "interval_eV": [a, b],
                "ratio": total.integrate(a, b) / measured.integrate(a, b),
            }
            for a, b in ((12.1, 16), (16, 20), (20, 25), (25, 30), (30, 40))
        ],
        "use": "Comparison only; no raw theoretical thresholds or unmatched grouped partials fitted.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nifs", type=Path, required=True)
    parser.add_argument("--o2-leiden", type=Path, required=True)
    parser.add_argument("--n2-leiden", type=Path, required=True)
    parser.add_argument("--mahla", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    nifs = json.loads(args.nifs.read_text())
    o2 = load_leiden(args.o2_leiden)
    # The 0.1-nm N2 file's separate absorption/dissociation resamplings do
    # not close near narrow *neutral* bands. Do not use those bands here.
    # Its positive photoionization column agrees with absorption on 25--100 eV.
    n2_leiden = load_leiden(args.n2_leiden, check_closure=False)["ionization"]
    n2_table = np.asarray(nifs["N2"]["continuum"])
    optical = {
        "N2": OpticalTable(n2_table[:, 0], n2_table[:, 2]),
        "O2": o2["ionization"],
    }
    output = {
        "status": "Provisional source sensitivity, not final calibration or production coefficients",
        "source_sha256": {
            key: source_digest(getattr(args, key))
            for key in ("nifs", "o2_leiden", "n2_leiden", "mahla")
        },
        "mahla_2025_audit": audit_mahla(load_mahla_o2(args.mahla), o2["ionization"]),
        "targets": {},
    }
    for target in ("N2", "O2"):
        problem = SourceFitProblem(target, optical[target])
        table = load_pstar(target)
        keep = table.energies >= 5e3
        losses = LossGrid(target, table.energies[keep])
        initial = SELECTED_PARAMETERS[target]
        reference_points = np.geomspace(25, 100, 401)
        other = (
            n2_leiden
            if target == "N2"
            else OpticalTable(
                np.asarray(nifs[target]["continuum"])[:, 0],
                np.asarray(nifs[target]["continuum"])[:, 2],
            )
        )
        results = {
            "evaluated_optical_reference_ratio_25_100eV": ratio_summary(
                other(reference_points) / optical[target](reference_points)
            ),
            "full_optical_response_moments": response_moments(nifs[target]),
            "baseline": summarize(problem, initial, losses, table.electronic[keep]),
        }
        trials = [("J_only", [0], initial, 1)]
        trials += [
            (f"six_optical_weight_{weight}", [0, 2, 3, 4, 6, 8], initial, weight)
            for weight in (0.5, 1, 2)
        ]
        trials += [
            (
                "five_center_numerator_zero",
                [0, 2, 3, 4, 8],
                replace(initial, center_scale=0),
                1,
            )
        ]
        for label, active, start, weight in trials:
            problem.optical_weight = weight
            parameters, fit = problem.fit(active, start)
            results[label] = summarize(
                problem, parameters, losses, table.electronic[keep]
            )
            results[label]["active_parameter_count"] = len(active)
            results[label]["evaluations"] = int(fit.nfev)
            results[label]["optimizer_success"] = bool(fit.success)
            results[label]["optimizer_message"] = fit.message
            results[label]["optimizer_optimality"] = float(fit.optimality)
            print(
                target,
                label,
                f"converged={fit.success}",
                f"objective={results[label]['objective_norm']:.6f}",
                f"max_pair/PSTAR={results[label]['maximum_pair_to_pstar']:.6f}",
                flush=True,
            )
        output["targets"][target] = results
    args.output.write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()
