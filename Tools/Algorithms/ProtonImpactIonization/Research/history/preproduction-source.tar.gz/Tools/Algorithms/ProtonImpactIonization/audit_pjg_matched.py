# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Reproduce old/new PJG comparisons and optional scientific figures.

The legacy expressions include the 1977 erratum, including ordinary addition
in Eq. (16). Preserve negative legacy values: silently clipping them would
hide the failure being audited. This script does not modify production data.
"""

import argparse
from pathlib import Path

import numpy as np
from experimental import (
    CROOKS_RUDD_1971_ENERGIES,
    CROOKS_RUDD_1971_TOTALS,
    RUDD_1979_N2_ENERGIES,
    RUDD_1979_N2_TOTALS,
)
from fit_pjg_matched import MomentGrid
from pjg_matched import SELECTED_PARAMETERS, kinematics, molecular_endpoint, sdcs
from pjg_repair import TARGETS
from reference import (
    BETHE_CONSTANT,
    ELECTRON_REST_ENERGY,
    PROTON_REST_ENERGY,
    free_maximum_transfer,
    rudd_sdcs,
    rudd_total,
)
from scipy.integrate import simpson

VARIANTS = ("printed", "corrected", "refit", "matched")
LABELS = {
    "printed": "Printed + 1977 erratum",
    "corrected": "Kinematics/algebra corrected",
    "refit": "Previous total-only refit",
    "matched": "New matched PJG",
}
COLORS = {
    "printed": "#929292",
    "corrected": "#d29533",
    "refit": "#b15179",
    "matched": "#007f88",
}
STYLES = {"printed": ":", "corrected": "--", "refit": "-.", "matched": "-"}


def legacy_cutoff(energy, variant):
    energy = np.asarray(energy)
    m, mass = ELECTRON_REST_ENERGY, PROTON_REST_ENERGY
    if variant == "printed":
        return energy * (energy + 2 * mass) / (energy + m + mass / m * (energy + mass))
    return free_maximum_transfer(energy)


def legacy_sdcs(target, energy, secondary, variant):
    """Printed, corrected-unrefitted, or previous production-refit SDCS."""
    if variant not in VARIANTS[:3]:
        raise ValueError("Unknown legacy model")
    energy, t = np.broadcast_arrays(energy, secondary)
    p = TARGETS[target]
    mass = PROTON_REST_ENERGY
    gamma, beta2, ee, maximum = kinematics(energy)
    cutoff = legacy_cutoff(energy, variant)
    width = p.gamma_s + p.gamma_numerator / (ee + p.gamma_denominator)
    center = p.center_s - p.center_numerator / (ee + p.center_denominator)
    b0, broad_center, delta = {"N2": (0.029, 53.3, 84), "O2": (0.030, 68.3, 132.1)}[
        target
    ]
    reduction = b0 * (np.log(ee / 8239) ** 2 + 1.035)
    j, amplitude = p.j, p.k
    if variant == "refit":
        j, amplitude = {"N2": (59.65, p.k), "O2": (19.28, 4.581e-16)}[target]
    distortion = 1 / (1 + (j / ee) ** p.power)
    logarithm = np.sum(
        np.array(p.fractions)
        * (
            np.log(
                4
                * ee[..., None]
                * gamma[..., None] ** 2
                * np.array(p.bethe_constants)
                / p.thresholds
                + np.e
            )
            - beta2[..., None]
        ),
        axis=-1,
    )
    soft = (
        amplitude
        * width**2
        * logarithm
        * (
            1 / ((t - center) ** 2 + width**2)
            - reduction / ((t - broad_center) ** 2 + p.broad_width**2)
        )
    )
    loss = t[..., None] + p.thresholds
    if variant == "printed":
        remainder = 1 / (4 * (energy[..., None] + 2 * mass) ** 2)
        remainder = remainder - 1 / ((cutoff[..., None] + p.thresholds + delta) * loss)
    else:
        remainder = 1 / (2 * (energy[..., None] + mass) ** 2)
        remainder = remainder - beta2[..., None] / (
            (maximum[..., None] + p.thresholds) * loss
        )
    hard = p.electrons * BETHE_CONSTANT * np.sum(p.fractions * remainder, axis=-1)
    return np.where((t >= 0) & (t <= cutoff), distortion / ee * (soft + hard), 0)


def spectrum(target, energy, secondary, variant):
    if variant == "matched":
        return sdcs(target, energy, secondary, SELECTED_PARAMETERS[target])
    return legacy_sdcs(target, energy, secondary, variant)


def moments(target, energies, variant, points=4097):
    energies = np.atleast_1d(energies)
    if variant == "matched":
        return MomentGrid(target, energies, points)(SELECTED_PARAMETERS[target])
    x = np.linspace(0, 1, points)[None, :] * np.log1p(
        legacy_cutoff(energies, variant)[:, None]
    )
    t = np.expm1(x)
    # Roundoff in expm1(log1p(cutoff)) must not remove the final endpoint.
    t = np.minimum(t, legacy_cutoff(energies, variant)[:, None])
    weighted = spectrum(target, energies[:, None], t, variant) * np.exp(x)
    total = simpson(weighted, x=x, axis=-1)
    return total, simpson(t * weighted, x=x, axis=-1) / total


def bhabha(target, energy, secondary):
    """Independent, unfactored free stationary-electron cross section."""
    _, beta2, ee, maximum = kinematics(energy)
    t = np.asarray(secondary)
    bracket = 1 - beta2 * t / maximum + t**2 / (2 * (energy + PROTON_REST_ENERGY) ** 2)
    return TARGETS[target].electrons * BETHE_CONSTANT / ee / t**2 * bracket


def tail_fraction(target, energy, continuation="exponential"):
    p = SELECTED_PARAMETERS[target]
    maximum = molecular_endpoint(target, energy, min(TARGETS[target].thresholds))
    x = np.linspace(np.log1p(free_maximum_transfer(energy)), np.log1p(maximum), 8193)
    tail = simpson(
        sdcs(target, energy, np.expm1(x), p, continuation=continuation) * np.exp(x), x=x
    )
    total, _ = MomentGrid(target, [energy], 8193, continuation)(p)
    return tail / total[0]


def report():
    for target in ("N2", "O2"):
        print(target)
        energies = np.geomspace(5e3, 4e6, 201)
        expected = rudd_total(target, energies)
        for variant in VARIANTS:
            total, _ = moments(target, energies, variant)
            ratio = total / expected
            print(
                variant,
                "total ratio min/max/log-RMS:",
                ratio.min(),
                ratio.max(),
                np.sqrt(np.mean(np.log(ratio) ** 2)),
            )
            sample_total, sample_mean = moments(
                target, [5e3, 10e3, 100e3, 1e6, 800e6], variant
            )
            print("totals:", sample_total, "mean energies:", sample_mean)
            t = np.array([1e4, 1e5, 5e5, 2e6])
            print(
                "800-MeV SDCS/Bhabha at 10/100/500/2000 keV:",
                spectrum(target, 800e6, t, variant) / bhabha(target, 800e6, t),
            )
        for energy in (5e3, 1e5, 1e6, 800e6):
            standard = MomentGrid(target, [energy], 8193)(SELECTED_PARAMETERS[target])
            alternative = MomentGrid(target, [energy], 8193, "constant")(
                SELECTED_PARAMETERS[target]
            )
            print(
                "tail/continuation sensitivity E, tail fraction, total, mean:",
                energy,
                tail_fraction(target, energy),
                alternative[0][0] / standard[0][0] - 1,
                alternative[1][0] / standard[1][0] - 1,
            )


def figures(directory):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "figure.dpi": 150,
            "savefig.dpi": 170,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.6), sharey=True)
    energies = np.geomspace(5e3, 4e6, 201)
    for ax, target in zip(axes, ("N2", "O2"), strict=True):
        for variant in VARIANTS:
            total, _ = moments(target, energies, variant)
            ax.loglog(
                energies / 1e3,
                total / rudd_total(target, energies),
                color=COLORS[variant],
                linestyle=STYLES[variant],
                linewidth=2,
                label=LABELS[variant],
            )
        ax.scatter(
            CROOKS_RUDD_1971_ENERGIES / 1e3,
            CROOKS_RUDD_1971_TOTALS[target]
            / rudd_total(target, CROOKS_RUDD_1971_ENERGIES),
            color="#242424",
            marker="o",
            s=22,
            zorder=5,
            label="1971 measured totals",
        )
        if target == "N2":
            ax.scatter(
                RUDD_1979_N2_ENERGIES / 1e3,
                RUDD_1979_N2_TOTALS / rudd_total(target, RUDD_1979_N2_ENERGIES),
                color="#242424",
                marker="+",
                s=45,
                zorder=5,
                label="1979 measured totals",
            )
        ax.axhline(1, color="black", linewidth=0.8)
        ax.axhspan(0.85, 1.15, color="#007f88", alpha=0.07)
        ax.set(title=target, xlabel="Proton kinetic energy (keV)", ylim=(0.1, 8))
        ax.grid(alpha=0.15, which="both")
    axes[0].set_ylabel("Total yield / Rudd recommended total")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=9)
    fig.suptitle("Total electron-production yield: old PJG and the new matched refit")
    fig.tight_layout(rect=(0, 0.14, 1, 0.94))
    fig.savefig(directory / "pjg_matched_totals.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.5), sharey=True)
    t = np.geomspace(1e3, 2.45e6, 1501)
    for ax, target in zip(axes, ("N2", "O2"), strict=True):
        for variant in VARIANTS:
            y = spectrum(target, 800e6, t, variant) / bhabha(target, 800e6, t)
            if variant != "matched":
                y = np.where(t <= legacy_cutoff(800e6, variant), y, np.nan)
            ax.semilogx(
                t / 1e3,
                y,
                color=COLORS[variant],
                linestyle=STYLES[variant],
                linewidth=2,
                label=LABELS[variant],
            )
        ax.axhline(1, color="black", linewidth=0.8)
        ax.axvline(
            legacy_cutoff(800e6, "printed") / 1e3, color=COLORS["printed"], linewidth=1
        )
        ax.axvline(free_maximum_transfer(800e6) / 1e3, color="black", linewidth=1)
        ax.set(
            title=target, xlabel="Secondary-electron energy (keV)", ylim=(-0.25, 1.4)
        )
        ax.grid(alpha=0.15)
    axes[0].set_ylabel("SDCS / complete free-electron Bhabha SDCS")
    fig.legend(
        *axes[0].get_legend_handles_labels(), loc="lower center", ncol=2, fontsize=9
    )
    fig.suptitle("800-MeV protons: the hard tail now has the correct normalization")
    fig.tight_layout(rect=(0, 0.14, 1, 0.94))
    fig.savefig(directory / "pjg_matched_bhabha.png")
    plt.close(fig)

    fig, axes = plt.subplots(2, 3, figsize=(12, 7.4), sharey=True)
    for row, target in enumerate(("N2", "O2")):
        samples = (5e3, 1e5, 1e6) if target == "N2" else (7.5e3, 1e5, 3e5)
        for col, energy in enumerate(samples):
            ax = axes[row, col]
            t = np.geomspace(
                2,
                min(8 * energy * ELECTRON_REST_ENERGY / PROTON_REST_ENERGY, 3000),
                500,
            )
            expected = rudd_sdcs(target, energy, t)
            mask = expected > 1e-4 * rudd_sdcs(target, energy, 2)
            t, expected = t[mask], expected[mask]
            for variant in ("printed", "refit", "matched"):
                ax.semilogx(
                    t,
                    spectrum(target, energy, t, variant) / expected,
                    color=COLORS[variant],
                    linestyle=STYLES[variant],
                    linewidth=2,
                    label=LABELS[variant],
                )
            ax.axhline(1, color="black", linewidth=0.8)
            ax.axvline(
                free_maximum_transfer(energy),
                color="#292929",
                linewidth=0.9,
                linestyle="--",
            )
            ax.axhspan(0.8, 1.2, color="#007f88", alpha=0.07)
            if target == "N2" and col == 0:
                ax.text(
                    0.03,
                    0.95,
                    "Old-model ratios above 2.5 are off scale",
                    transform=ax.transAxes,
                    va="top",
                    fontsize=8,
                    color="#555555",
                )
            ax.set(
                title=f"{target}, {energy / 1e3:g} keV protons",
                ylim=(0, 2.5),
                xlim=(2, t[-1]),
            )
            ax.grid(alpha=0.15)
            if col == 0:
                ax.set_ylabel("SDCS / Rudd recommended SDCS")
            if row == 1:
                ax.set_xlabel("Secondary-electron energy (eV)")
    fig.legend(
        *axes[0, 0].get_legend_handles_labels(), loc="lower center", ncol=3, fontsize=9
    )
    fig.suptitle(
        "Spectral comparison, including the bound-electron tail above free Tmax"
    )
    fig.tight_layout(rect=(0, 0.06, 1, 0.95))
    fig.savefig(directory / "pjg_matched_spectra.png")
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--figures", help="Optional directory for generated PNG figures"
    )
    args = parser.parse_args()
    report()
    if args.figures:
        figures(args.figures)
