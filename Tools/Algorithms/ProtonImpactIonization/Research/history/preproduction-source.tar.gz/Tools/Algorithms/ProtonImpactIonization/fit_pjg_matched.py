# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Fit both gases with a unified, Bhabha-normalized PJG formulation.

No production coefficients or files are modified by this script. The
objective is a transparent weighted model/data comparison, not a chi-squared
statistic: reference-curve samples and original measurements are correlated.
"""

import argparse
from dataclasses import astuple, replace

import numpy as np
from experimental import (
    CROOKS_RUDD_1971_ENERGIES,
    CROOKS_RUDD_1971_TOTALS,
    RUDD_1979_N2_ENERGIES,
    RUDD_1979_N2_MEAN_ENERGIES,
    RUDD_1979_N2_TOTALS,
)
from fit_pjg_optical import n2_photoelectron_coefficient
from fit_pjg_repair import spectral_grid
from pjg_matched import (
    MatchedParameters,
    SpectrumGrid,
    initial_parameters,
    molecular_endpoint,
    optical_coefficient,
)
from pjg_repair import TARGETS
from reference import BOHR_RADIUS, RYDBERG, free_maximum_transfer, rudd_total
from scipy.integrate import simpson
from scipy.optimize import least_squares


def o2_photoelectron_coefficient(secondary, path):
    """Coarse O2 optical diagnostic from an external NCAR/GLOW reference table.

    Input: NCAR/GLOW data/ephoto_xo2.dat, revision
    6cb880d0e112810dbe9a79203f0183f9b07e3473. See MATCHED_PJG.md for its
    verified SHA-256 digest and source URL.
    Thresholds and cm^2 conversion follow its ephoto.f90. Use ionization,
    not absorption, and normalize rounded branching fractions. The finite
    0--100 eV audit window needs no extrapolation and is below the Auger
    region. Dissociative channels use GLOW's effective thresholds; this is
    not channel-resolved precision optical data or an inclusive decay model.
    The external table is not copied into WarpX by this script.
    """
    t = np.asarray(secondary, dtype=float)
    if np.any(~np.isfinite(t)) or np.any((t < 0) | (t > 100)):
        raise ValueError("The O2 optical audit requires 0 <= T <= 100 eV")
    table = np.loadtxt(path, skiprows=4)[::-1]
    energy = 12398.41984332 / ((table[:, 0] + table[:, 1]) / 2)
    fractions = table[:, 2:8]
    sums = fractions.sum(axis=1)
    fractions = np.divide(
        fractions, sums[:, None], out=np.zeros_like(fractions), where=sums[:, None] > 0
    )
    photon_factor = 4 * np.pi**2 * (7.2973525643e-3) * BOHR_RADIUS**2 * RYDBERG
    result = np.zeros_like(t)
    for channel, threshold in enumerate((12.07, 16.10, 18.20, 20.00)):
        loss = t + threshold
        cross_section = np.interp(loss, energy, fractions[:, channel] * table[:, 8])
        result += cross_section * 1e-18 / photon_factor / loss
    return result


class MomentGrid:
    def __init__(self, target, energies, points=1025, continuation="exponential"):
        self.energy = np.asarray(energies, dtype=float)
        maximum = molecular_endpoint(
            target, self.energy, min(TARGETS[target].thresholds)
        )
        self.x = np.linspace(0, 1, points)[None, :] * np.log1p(maximum[:, None])
        self.t = np.expm1(self.x)
        self.grid = SpectrumGrid(target, self.energy[:, None], self.t, continuation)

    def __call__(self, parameters, hard_distortion="fading", center_s=None):
        weighted = self.grid(parameters, hard_distortion, center_s) * np.exp(self.x)
        total = simpson(weighted, x=self.x, axis=-1)
        mean = simpson(self.t * weighted, x=self.x, axis=-1) / total
        return total, mean


class FitProblem:
    def __init__(
        self, target, o2_optical=None, optical_weight=0.25, hard_distortion="fading"
    ):
        self.target = target
        self.optical_weight = optical_weight
        self.hard_distortion = hard_distortion
        self.energies = np.geomspace(5e3, 4e6, 31)
        self.moments = MomentGrid(target, self.energies)
        self.total_reference = rudd_total(target, self.energies)
        se, st, self.spectral_reference = spectral_grid(target)
        self.spectra = SpectrumGrid(target, se, st)
        self.optical_t = np.geomspace(2, 100, 40)
        self.optical_reference = (
            n2_photoelectron_coefficient(self.optical_t)
            if target == "N2"
            else o2_photoelectron_coefficient(self.optical_t, o2_optical)
        )
        self.original_moments = (
            MomentGrid(target, RUDD_1979_N2_ENERGIES) if target == "N2" else None
        )

    def residual(self, parameters, center_s=None):
        total, _ = self.moments(parameters, self.hard_distortion, center_s)
        ratio = (
            self.spectra(parameters, self.hard_distortion, center_s)
            / self.spectral_reference
        )
        blocks = [
            np.log(total / self.total_reference) / np.sqrt(len(total)),
            np.log(ratio) / np.sqrt(len(ratio)),
        ]
        if self.optical_weight > 0:
            optical = optical_coefficient(
                self.target, self.optical_t, parameters, center_s=center_s
            )
            blocks.append(
                self.optical_weight
                * np.log(optical / self.optical_reference)
                / np.sqrt(len(optical))
            )
        if self.original_moments is not None:
            original_total, original_mean = self.original_moments(
                parameters, self.hard_distortion, center_s
            )
            blocks.extend(
                (
                    0.4 * np.log(original_total / RUDD_1979_N2_TOTALS) / np.sqrt(8),
                    0.5
                    * np.log(original_mean / RUDD_1979_N2_MEAN_ENERGIES)
                    / np.sqrt(8),
                )
            )
        return np.concatenate(blocks)

    def fit(self, active, initial=None):
        defaults = np.array(astuple(initial or initial_parameters(self.target)))
        active = np.asarray(active)
        lower = np.array([0.01, 0.1, 0.01, 0.1, 1, 1e-4, 1e-4, 0.02, 0.25])[active]
        upper = np.array([1e5, 4, 10, 100, 1000, 100, 5, 5, 4])[active]

        def unpack(values):
            parameters = defaults.copy()
            parameters[active] = np.exp(values)
            return MatchedParameters(*parameters)

        fit = least_squares(
            lambda values: self.residual(unpack(values)),
            np.log(defaults[active]),
            bounds=(np.log(lower), np.log(upper)),
            max_nfev=600,
            ftol=1e-10,
            xtol=1e-10,
            gtol=1e-9,
        )
        if not fit.success:
            raise RuntimeError(fit.message)
        return unpack(fit.x), fit

    def report(self, parameters):
        target = self.target
        total, _ = self.moments(parameters, self.hard_distortion)
        ratio = self.spectra(parameters, self.hard_distortion) / self.spectral_reference
        optical = (
            optical_coefficient(target, self.optical_t, parameters)
            / self.optical_reference
        )
        print(target, parameters, flush=True)
        print("Objective norm:", np.linalg.norm(self.residual(parameters)))
        print(
            "Recommended total ratios:",
            np.min(total / self.total_reference),
            np.max(total / self.total_reference),
        )
        print(
            "SDCS ratio percentiles 0/10/50/90/100:",
            np.percentile(ratio, [0, 10, 50, 90, 100]),
        )
        print(
            "Optical ratio percentiles 0/10/50/90/100:",
            np.percentile(optical, [0, 10, 50, 90, 100]),
        )
        original, _ = MomentGrid(target, CROOKS_RUDD_1971_ENERGIES)(
            parameters, self.hard_distortion
        )
        print("1971 original total ratios:", original / CROOKS_RUDD_1971_TOTALS[target])
        if self.original_moments is not None:
            original, mean = self.original_moments(parameters, self.hard_distortion)
            print("1979 original total ratios:", original / RUDD_1979_N2_TOTALS)
            print("1979 mean energy ratios:", mean / RUDD_1979_N2_MEAN_ENERGIES)
        for energy in (5e3, 10e3, 100e3, 1e6, 800e6):
            maximum = molecular_endpoint(
                target, energy, min(TARGETS[target].thresholds)
            )
            x = np.linspace(
                np.log1p(free_maximum_transfer(energy)), np.log1p(maximum), 4097
            )
            tail = simpson(
                SpectrumGrid(target, energy, np.expm1(x))(
                    parameters, self.hard_distortion
                )
                * np.exp(x),
                x=x,
            )
            total, mean = MomentGrid(target, [energy], points=4097)(
                parameters, self.hard_distortion
            )
            print("E/total/mean/free-tail:", energy, total[0], mean[0], tail / total[0])
        print(flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=("N2", "O2"))
    parser.add_argument("--o2-optical")
    parser.add_argument("--optical-weight", type=float, default=0.25)
    parser.add_argument("--free-power", action="store_true")
    parser.add_argument("--free-width", action="store_true")
    parser.add_argument("--free-edge", action="store_true")
    parser.add_argument("--fixed-center", action="store_true")
    parser.add_argument("--fixed-log", action="store_true")
    parser.add_argument("--binding-log", action="store_true")
    parser.add_argument(
        "--multistart",
        type=int,
        default=0,
        help="Repeat the fit from this many perturbed starting points",
    )
    parser.add_argument(
        "--hard-distortion", choices=("fading", "common", "none"), default="fading"
    )
    args = parser.parse_args()
    if args.target != "N2" and not args.o2_optical:
        parser.error(
            "The O2 refit needs --o2-optical with the external reference table"
        )
    if args.multistart < 0:
        parser.error("--multistart must be nonnegative")
    rng = np.random.default_rng(24711)
    for target in (args.target,) if args.target else ("N2", "O2"):
        problem = FitProblem(
            target, args.o2_optical, args.optical_weight, args.hard_distortion
        )
        active = [0, 2, 3, 4]
        if args.free_power:
            active.append(1)
        if args.free_width:
            active.append(7)
        if args.free_edge:
            active.append(8)
        if not args.fixed_log and not args.binding_log:
            active.append(5)
        if not args.fixed_center:
            active.append(6)
        initial = initial_parameters(target)
        if args.binding_log:
            p = TARGETS[target]
            c = np.exp(
                np.dot(p.fractions, np.log(np.array(p.bethe_constants) / p.thresholds))
            )
            initial = replace(
                initial, bethe_scale=1 / (c * np.dot(p.fractions, p.thresholds))
            )
        parameters, fit = problem.fit(active, initial)
        print("Active parameters:", active, "evaluations:", fit.nfev)
        problem.report(parameters)
        baseline = np.array(astuple(parameters))
        for iteration in range(args.multistart):
            trial = baseline.copy()
            trial[active] *= np.exp(rng.uniform(-0.7, 0.7, len(active)))
            alternate, fit = problem.fit(active, MatchedParameters(*trial))
            relative = np.array(astuple(alternate))[active] / baseline[active] - 1
            print(
                "Additional start/evaluations/objective/max parameter change:",
                iteration + 1,
                fit.nfev,
                np.linalg.norm(problem.residual(alternate)),
                np.max(np.abs(relative)),
                flush=True,
            )


if __name__ == "__main__":
    main()
