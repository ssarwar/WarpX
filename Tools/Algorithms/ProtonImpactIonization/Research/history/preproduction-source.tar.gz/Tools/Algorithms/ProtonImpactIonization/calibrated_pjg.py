# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Frozen N2/O2 proton energy-model calibration of September 2026.

See FINAL_PJG.md for the formulation, sources, uncertainty treatment, and
limitations. This is an offline reference, not the production GPU sampler.
The observable is inclusive electron yield represented by effective pairs.
Incident energies above 4 MeV are extrapolations; the interface is limited
to the 5 keV--10 GeV numerical audit range. No secondary-energy cut is used.
"""

from types import MappingProxyType

import numpy as np
from pjg_matched import MatchedParameters, binding_log_scale
from pjg_matched import sdcs as reference_sdcs
from stopping_pjg_matched import LossGrid

PARAMETERS = MappingProxyType(
    {
        "N2": MatchedParameters(
            j=13.8235317299573,
            power=0.807,
            amplitude=0.8812026712177866,
            width=12.503227296612915,
            broad_excess=88.54007881169514,
            bethe_scale=binding_log_scale("N2"),
            center_scale=0.17909741025355236,
            low_width_ratio=1,
            edge_scale=1.1911400606628986,
        ),
        "O2": MatchedParameters(
            j=8.76635921598519,
            power=1.314,
            amplitude=0.7815344574102883,
            width=16.757498368297895,
            broad_excess=159.2697988004284,
            bethe_scale=binding_log_scale("O2"),
            center_scale=0.37449064801445814,
            low_width_ratio=1,
            edge_scale=1,
        ),
    }
)


def checked_energies(energy):
    """Reject incident energies outside the numerical audit range."""
    energy = np.asarray(energy, dtype=float)
    if np.any(~np.isfinite(energy)) or np.any((energy < 5e3) | (energy > 1e10)):
        raise ValueError("The calibrated reference requires 5 keV <= E <= 10 GeV")
    return energy


def sdcs(target, energy, secondary):
    """Inclusive electron SDCS, cm^2/eV per molecule; both energies in eV."""
    return reference_sdcs(
        target, checked_energies(energy), secondary, PARAMETERS[target]
    )


def total_cross_section(target, energy, points=2049):
    """Integrate this same SDCS, in cm^2; no independent normalization fit.

    The segmented quadrature is a host-side reference for table generation.
    Calling it separately for every PIC collision would be inappropriate.
    """
    energy = checked_energies(energy)
    result = LossGrid(target, energy.ravel(), points)(PARAMETERS[target]).total
    return result.reshape(energy.shape)
