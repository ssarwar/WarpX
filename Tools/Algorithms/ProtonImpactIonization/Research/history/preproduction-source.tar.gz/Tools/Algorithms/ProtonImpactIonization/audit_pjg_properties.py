# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Audit source-trial energy distributions without promoting coefficients.

Keep full-spectrum moments distinct from measured-window moments. The
effective-pair binding cost is a modeling convention, not a measurement of
inclusive projectile loss, and is not the cascade-inclusive gas W value.
The angular check deliberately records a failure of the current practical
IAA closure; mathematical normalization does not establish DDCS accuracy.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from audit_pjg_matched import legacy_sdcs
from audit_pjg_matched import moments as legacy_moments
from experimental import (
    CROOKS_RUDD_1971_ENERGIES,
    CROOKS_RUDD_1971_TOTALS,
    RUDD_1979_N2_ENERGIES,
    RUDD_1979_N2_MEAN_ENERGIES,
    RUDD_1979_N2_TOTALS,
)
from pjg_matched import (
    MatchedParameters,
    SpectrumGrid,
    kinematics,
    molecular_angular_fraction,
    sample_polar_cosine,
)
from pjg_repair import TARGETS
from reference import rudd_sdcs
from scipy.integrate import cumulative_trapezoid, simpson
from scipy.special import expit
from source_datasets import (
    RUDD_1983_ENERGIES,
    RUDD_1983_FITTED_TOTALS,
    cheng_1989_figure1,
    source_digest,
)
from stopping_pjg_matched import (
    LossGrid,
    free_second_moment,
    load_pstar,
    mass_stopping,
    rudd_nominal_loss,
)

TRIALS = (
    "baseline",
    "six_optical_weight_0.5",
    "six_optical_weight_1",
    "six_optical_weight_2",
    "five_center_numerator_zero",
)
CURRENT = "six_optical_weight_1"
ENERGIES = np.array(
    [
        5e3,
        7e3,
        7.5e3,
        10e3,
        15e3,
        20e3,
        30e3,
        50e3,
        70e3,
        100e3,
        150e3,
        200e3,
        300e3,
        500e3,
        700e3,
        1e6,
        1.5e6,
        2e6,
        3e6,
        4e6,
        10e6,
        100e6,
        800e6,
        1e9,
        1e10,
    ]
)


def power_law_moments(x, y, orders=(0, 1, 2)):
    """Integrate a positive piecewise log-log interpolant, without extrapolation.

    For y=C*T**a each cell contributes C*(b**r-a**r)/r,
    r=a+order+1. The expm1 form retains the logarithmic r -> 0 limit.
    Sparse measured points do not resolve resonances or unmeasured tails.
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    if (
        x.ndim != 1
        or y.shape != x.shape
        or len(x) < 2
        or np.any(~np.isfinite(x))
        or np.any(~np.isfinite(y))
        or np.any(x <= 0)
        or np.any(y <= 0)
        or np.any(np.diff(x) <= 0)
    ):
        raise ValueError("Require ordered positive finite energies and SDCS values")
    log_step = np.log(x[1:] / x[:-1])
    slope = np.log(y[1:] / y[:-1]) / log_step
    result = []
    for order in orders:
        exponent = slope + order + 1
        factor = np.divide(
            np.expm1(exponent * log_step),
            exponent,
            out=log_step.copy(),
            where=np.abs(exponent) > 1e-14,
        )
        result.append(np.sum(y[:-1] * x[:-1] ** (order + 1) * factor))
    return np.asarray(result)


def mapped_cdf(secondary, weighted_density, dx):
    """Return a positive, monotone CDF across contiguous mapped segments.

    Trapezoidal integration preserves positivity. Moments elsewhere use
    Simpson integration, so the CDF normalization difference is recorded.
    This research calculation is not the GPU sampling implementation.
    """
    secondary = np.asarray(secondary)
    weighted_density = np.asarray(weighted_density)
    if (
        secondary.ndim != 2
        or secondary.shape[0] < 1
        or secondary.shape[1] < 2
        or secondary.shape != weighted_density.shape
        or np.any(~np.isfinite(weighted_density))
        or np.any(weighted_density < 0)
        or dx <= 0
        or not np.isfinite(dx)
        or np.any(~np.isfinite(secondary))
        or np.any(np.diff(secondary, axis=1) < 0)
        or not np.allclose(secondary[1:, 0], secondary[:-1, -1], rtol=1e-14, atol=0)
    ):
        raise ValueError("Require contiguous ordered segments and nonnegative density")
    cumulative = cumulative_trapezoid(weighted_density, dx=dx, axis=-1, initial=0)
    offset = np.r_[0, np.cumsum(cumulative[:-1, -1])]
    cumulative += offset[:, None]
    normalization = cumulative[-1, -1]
    if normalization <= 0 or not np.isfinite(normalization):
        raise ValueError("The distribution must have a positive finite integral")
    x = np.r_[secondary[0], secondary[1:, 1:].ravel()]
    cdf = np.r_[cumulative[0], cumulative[1:, 1:].ravel()] / normalization
    return x, cdf, float(normalization)


def distribution_properties(target, parameters, energies=ENERGIES, points=4097):
    grid = LossGrid(target, energies, points)
    moment = grid(parameters)
    soft, hard = grid.grid.parts(parameters)
    density = soft + hard
    hard_total = simpson(hard * grid.jacobian, dx=grid.dx, axis=-1).sum(axis=1)
    hard_loss = simpson(hard * grid.jacobian * grid.secondary, dx=grid.dx, axis=-1).sum(
        axis=1
    )
    mean = moment.kinetic / moment.total
    second = moment.kinetic_second / moment.total
    variance = second - mean**2
    _, beta2, _, maximum = kinematics(grid.energies)
    records = []
    for index, energy in enumerate(grid.energies):
        x, cdf, area = mapped_cdf(
            grid.secondary[index], density[index] * grid.jacobian[index], grid.dx
        )
        # Keep the left side of a CDF plateau. The requested quantiles are
        # interior, so an underflowed far-tail plateau cannot move an endpoint.
        keep = np.r_[True, np.diff(cdf) > 0]
        quantiles = np.interp([0.5, 0.9, 0.99], cdf[keep], x[keep])
        thresholds = [2, min(TARGETS[target].thresholds), 100, 1000, 10000]
        probability_below = np.interp(thresholds, x, cdf)
        sigma = moment.total[index]
        records.append(
            {
                "energy_eV": float(energy),
                "sigma_e_cm2": float(sigma),
                "mean_T_eV": float(mean[index]),
                "mean_T2_eV2": float(second[index]),
                "standard_deviation_T_eV": float(np.sqrt(variance[index])),
                "quantile_50_90_99_eV": quantiles.tolist(),
                "thresholds_eV": thresholds,
                "probability_below_threshold": probability_below.tolist(),
                "free_Tmax_eV": float(maximum[index]),
                "molecular_Tmax_eV": float(grid.secondary[index, -1, -1]),
                "above_free_count_energy_second_fraction": [
                    float(moment.tail_total[index] / sigma),
                    float(moment.tail_kinetic[index] / moment.kinetic[index]),
                    float(
                        moment.tail_kinetic_second[index] / moment.kinetic_second[index]
                    ),
                ],
                "effective_binding_eV": float(moment.binding[index] / sigma),
                "effective_pair_cost_eV": float(moment.ionization[index] / sigma),
                "kinetic_mass_stopping": float(
                    mass_stopping(target, moment.kinetic[index])
                ),
                "binding_mass_stopping": float(
                    mass_stopping(target, moment.binding[index])
                ),
                "pair_mass_stopping": float(
                    mass_stopping(target, moment.ionization[index])
                ),
                "hard_count_fraction": float(hard_total[index] / sigma),
                "hard_kinetic_fraction": float(
                    hard_loss[index] / moment.kinetic[index]
                ),
                "second_moment_to_free": float(
                    moment.kinetic_second[index] / free_second_moment(target, energy)
                ),
                # Convert sigma from cm^2 to m^2; c is exact in SI units.
                "rate_coefficient_m3_per_s": float(
                    sigma * 1e-4 * 299792458 * np.sqrt(beta2[index])
                ),
                "iid_energy_relative_variance_times_N": float(
                    variance[index] / mean[index] ** 2
                ),
                "compound_poisson_relative_variance_times_expected_N": float(
                    second[index] / mean[index] ** 2
                ),
                "cdf_to_simpson_relative_difference": float(area / sigma - 1),
                "nonnegative": bool(np.all(density[index] >= 0)),
                "cdf_monotone": bool(np.all(np.diff(cdf) >= 0)),
                "bounded_second_moment": bool(second[index] <= x[-1] * mean[index]),
            }
        )
    return records


def measured_window_comparisons(parameters):
    data = cheng_1989_figure1()
    records = []
    for energy in np.unique(data[:, 0]):
        group = data[data[:, 0] == energy]
        measured = power_law_moments(group[:, 1], group[:, 2])
        x = np.linspace(np.log(group[0, 1]), np.log(group[-1, 1]), 8193)
        t = np.exp(x)
        record = {
            "energy_eV": float(energy),
            "window_eV": group[[0, -1], 1].tolist(),
            "measured_window_mean_eV": float(measured[1] / measured[0]),
            "measured_window_integral_cm2": float(measured[0]),
            "interpretation": "Digitized, rescaled Fig. 1; power-law interpolation; no extrapolation.",
        }
        models = {
            label: SpectrumGrid("O2", energy, t)(p) for label, p in parameters.items()
        }
        models["rudd_1992_formula"] = rudd_sdcs("O2", energy, t)
        for label, spectrum in models.items():
            moments = [simpson(spectrum * t ** (order + 1), x=x) for order in (0, 1, 2)]
            record[label] = {
                "window_mean_eV": float(moments[1] / moments[0]),
                "window_integral_to_data": float(moments[0] / measured[0]),
            }
        records.append(record)
    return records


def angular_support(target, parameters, energy=50e3, secondaries=(10, 50, 100, 150)):
    result = []
    for t in secondaries:
        grid = SpectrumGrid(target, energy, t)
        weights, lower, upper, phase = [], [], [], []
        for argument, weight, binding in grid.gate_terms:
            allowed = molecular_angular_fraction(target, energy, t, binding)
            if allowed <= 0:
                continue
            weights.append(weight * expit(parameters.edge_scale * argument))
            lower.append(sample_polar_cosine(target, energy, t, binding, 0))
            upper.append(
                sample_polar_cosine(target, energy, t, binding, np.nextafter(1.0, 0))
            )
            phase.append(allowed)
        weights = np.asarray(weights) / np.sum(weights)
        lower, upper = np.asarray(lower), np.asarray(upper)
        backward = np.clip(-lower / (upper - lower), 0, 1)
        result.append(
            {
                "proton_energy_eV": energy,
                "secondary_energy_eV": t,
                "maximum_angle_degrees": float(np.degrees(np.arccos(np.min(lower)))),
                "backward_probability": float(np.dot(weights, backward)),
                "mean_polar_cosine": float(np.dot(weights, (lower + upper) / 2)),
                "minimum_molecular_allowed_solid_angle_fraction": float(min(phase)),
                "interpretation": "Angular closure prediction, not a fit to measured DDCS.",
            }
        )
    return result


def stopping_comparisons(target, parameters):
    table = load_pstar(target)
    keep = table.energies >= 5000
    energies, reference = table.energies[keep], table.electronic[keep]
    grid = LossGrid(target, energies, points=2049)
    result = {}
    for label, p in parameters.items():
        m = grid(p)
        kinetic, binding = (
            mass_stopping(target, m.kinetic),
            mass_stopping(target, m.binding),
        )
        pair = kinetic + binding
        result[label] = [
            {
                "energy_eV": float(e),
                "kinetic_mass_stopping": float(k),
                "binding_mass_stopping": float(b),
                "pair_mass_stopping": float(s),
                "nist_electronic_mass_stopping": float(ref),
                "pair_to_nist": float(s / ref),
                "remaining_nist_budget": float(ref - s),
                "nist_cost_per_primary_electron_eV": float(
                    ref / mass_stopping(target, sigma)
                ),
            }
            for e, k, b, s, ref, sigma in zip(
                energies, kinetic, binding, pair, reference, m.total, strict=True
            )
        ]
    # The nonrelativistic Rudd formula is compared only inside 5--4000 keV.
    e = energies[energies <= 4e6]
    rudd = mass_stopping(target, rudd_nominal_loss(target, e))
    result["rudd_1992_nominal_orbital_loss"] = np.c_[
        e, rudd, rudd / reference[: len(e)]
    ].tolist()
    return result


def legacy_comparisons(target):
    records = {}
    for variant in ("printed", "corrected", "refit"):
        total, mean = legacy_moments(target, ENERGIES, variant)
        records[variant] = [
            {
                "energy_eV": float(e),
                "signed_total_cm2": float(s),
                "signed_mean_eV": float(t),
            }
            for e, s, t in zip(ENERGIES, total, mean, strict=True)
        ]
        for record in records[variant]:
            samples = np.geomspace(1e-4, record["energy_eV"], 4097)
            record["sampled_negative_sdcs"] = bool(
                np.any(legacy_sdcs(target, record["energy_eV"], samples, variant) < 0)
            )
    return records


def property_convergence(target, parameters):
    """Check quantiles independently of the high-order moment integration."""
    energy = [5e3, 50e3, 1e6, 800e6, 1e10]
    coarse = distribution_properties(target, parameters, energy, points=2049)
    fine = distribution_properties(target, parameters, energy, points=8193)
    return {
        "energies_eV": energy,
        "relative_change_2049_to_8193": {
            key: float(
                np.max(
                    np.abs(
                        np.array([r[key] for r in coarse])
                        / np.array([r[key] for r in fine])
                        - 1
                    )
                )
            )
            for key in (
                "sigma_e_cm2",
                "mean_T_eV",
                "mean_T2_eV2",
                "quantile_50_90_99_eV",
                "pair_mass_stopping",
            )
        },
    }


def plot_properties(data, directory):
    import matplotlib.pyplot as plt

    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}
    )
    styles = (
        ("baseline", "Previous matched PJG", "#777777"),
        (CURRENT, "Source trial, optical weight 1", "#0072B2"),
        ("six_optical_weight_2", "Source trial, optical weight 2", "#D55E00"),
    )
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8), constrained_layout=True)
    for col, target in enumerate(TARGETS):
        for label, name, color in styles:
            rows = data["targets"][target]["distributions"][label]
            energy = np.array([r["energy_eV"] for r in rows]) / 1000
            keep = energy <= 4000
            axes[0, col].loglog(
                energy[keep],
                np.array([r["sigma_e_cm2"] for r in rows])[keep] * 1e16,
                color=color,
                label=name,
            )
            axes[1, col].semilogx(
                energy[keep],
                np.array([r["mean_T_eV"] for r in rows])[keep],
                color=color,
            )
        axes[0, col].scatter(
            RUDD_1983_ENERGIES / 1000,
            RUDD_1983_FITTED_TOTALS[target] * 1e16,
            marker="+",
            c="black",
            label="Rudd 1983 table: authors' fit",
            zorder=4,
        )
        axes[0, col].scatter(
            CROOKS_RUDD_1971_ENERGIES / 1000,
            CROOKS_RUDD_1971_TOTALS[target] * 1e16,
            facecolor="none",
            edgecolor="#009E73",
            label="Crooks 1971 measurements",
            zorder=4,
        )
        axes[0, col].set(
            title=target,
            ylabel=r"Electron yield cross section ($10^{-16}$ cm$^2$)",
            xlabel="Proton energy (keV)",
        )
        axes[1, col].set(
            ylabel="Full-spectrum mean secondary energy (eV)",
            xlabel="Proton energy (keV)",
        )
        if target == "N2":
            axes[1, col].scatter(
                RUDD_1979_N2_ENERGIES / 1000,
                RUDD_1979_N2_MEAN_ENERGIES,
                facecolor="none",
                edgecolor="black",
                label="Rudd 1979 measured mean",
                zorder=4,
            )
            axes[1, col].legend(fontsize=8)
        else:
            axes[1, col].text(
                0.04,
                0.9,
                "No full-spectrum O₂ mean-energy table\nverified in the present source set.",
                transform=axes[1, col].transAxes,
                fontsize=9,
            )
        for row in range(2):
            axes[row, col].grid(alpha=0.2)
    axes[0, 0].legend(fontsize=7.5)
    fig.suptitle(
        "Provisional PJG source refits — measured points and recommended fits kept distinct"
    )
    fig.savefig(directory / "totals_and_means.png", dpi=170)
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8), constrained_layout=True)
    for col, target in enumerate(TARGETS):
        rows = data["targets"][target]["stopping"][CURRENT]
        e = np.array([r["energy_eV"] for r in rows]) / 1e6
        for key, label, color in (
            (
                "nist_electronic_mass_stopping",
                "NIST electronic (all processes)",
                "black",
            ),
            ("pair_mass_stopping", "Effective pair loss", "#0072B2"),
            ("kinetic_mass_stopping", "Electron kinetic energy only", "#009E73"),
            ("binding_mass_stopping", "Effective binding cost", "#CC79A7"),
        ):
            axes[0, col].loglog(e, [r[key] for r in rows], label=label, color=color)
        for label, name, color in styles:
            rows = data["targets"][target]["stopping"][label]
            axes[1, col].semilogx(
                e, [r["pair_to_nist"] for r in rows], label=name, color=color
            )
        rudd = np.array(
            data["targets"][target]["stopping"]["rudd_1992_nominal_orbital_loss"]
        )
        axes[1, col].semilogx(
            rudd[:, 0] / 1e6,
            rudd[:, 2],
            linestyle="--",
            color="#882255",
            label="NR Rudd: nominal orbital loss",
        )
        axes[1, col].axhline(1, color="black", linestyle=":", linewidth=1)
        axes[0, col].set(title=target, ylabel=r"Mass stopping (MeV cm$^2$/g)")
        axes[1, col].set(ylabel="Effective pair loss / NIST electronic", ylim=(0, 1.12))
        for row in range(2):
            axes[row, col].set_xlabel("Proton energy (MeV)")
            axes[row, col].grid(alpha=0.2)
    axes[0, 0].legend(fontsize=8)
    axes[1, 0].legend(fontsize=8)
    fig.suptitle(
        "Ionization loss is not complete stopping; high-energy results are extrapolations"
    )
    fig.savefig(directory / "stopping_decomposition.png", dpi=170)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fits", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--figures", type=Path)
    args = parser.parse_args()
    source = json.loads(args.fits.read_text())
    result = {
        "status": "Research audit only; no production coefficients promoted.",
        "source_fit_sha256": source_digest(args.fits),
        "units": {
            "energy": "eV",
            "cross_section": "cm^2 per molecule",
            "mass_stopping": "MeV cm^2/g",
        },
        "targets": {},
    }
    for target in TARGETS:
        parameters = {
            label: MatchedParameters(**source["targets"][target][label]["parameters"])
            for label in TRIALS
        }
        result["targets"][target] = {
            "distributions": {
                label: distribution_properties(target, p)
                for label, p in parameters.items()
            },
            "stopping": stopping_comparisons(target, parameters),
            "legacy_signed_moments": legacy_comparisons(target),
            "angular_support": angular_support(target, parameters[CURRENT]),
            "numerical_convergence": property_convergence(target, parameters[CURRENT]),
        }
        if target == "N2":
            result["targets"][target]["rudd_1979_measured_mean"] = np.c_[
                RUDD_1979_N2_ENERGIES, RUDD_1979_N2_TOTALS, RUDD_1979_N2_MEAN_ENERGIES
            ].tolist()
        else:
            result["targets"][target]["cheng_measured_windows"] = (
                measured_window_comparisons(parameters)
            )
        print(target, "properties complete", flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    if args.figures:
        plot_properties(result, args.figures)


if __name__ == "__main__":
    main()
