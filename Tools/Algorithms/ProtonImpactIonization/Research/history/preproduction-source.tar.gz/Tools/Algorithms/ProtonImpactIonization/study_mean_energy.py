# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Test measured N2 mean-energy sensitivity using the same six SDCS parameters.

The data-block weights express research priorities, not independent
standard errors. Do not select a final fit by comparing objective norms
from different weighting choices. NIST stopping is an external diagnostic,
never an equality target for the effective-pair source.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from experimental import RUDD_1979_N2_ENERGIES, RUDD_1979_N2_MEAN_ENERGIES
from pjg_matched import MatchedParameters
from source_datasets import OpticalTable, source_digest
from stopping_pjg_matched import LossGrid, load_pstar
from study_source_refresh import SourceFitProblem, summarize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fits", type=Path, required=True)
    parser.add_argument("--nifs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--figures", type=Path)
    args = parser.parse_args()
    source = json.loads(args.fits.read_text())["targets"]["N2"]
    table = np.asarray(json.loads(args.nifs.read_text())["N2"]["continuum"])
    optical = OpticalTable(table[:, 0], table[:, 2])
    pstar = load_pstar("N2")
    keep = pstar.energies >= 5e3
    grid = LossGrid("N2", pstar.energies[keep])
    output = {
        "status": "Unpromoted N2 sensitivity: same six adjustable SDCS coefficients.",
        "source_sha256": {
            "fits": source_digest(args.fits),
            "nifs": source_digest(args.nifs),
        },
        "trials": {},
    }
    for optical_weight, mean_weight in ((1, 0.5), (1, 1), (1, 2), (1, 4), (0.5, 2)):
        problem = SourceFitProblem("N2", optical, optical_weight, mean_weight)
        initial = MatchedParameters(**source["six_optical_weight_1"]["parameters"])
        if optical_weight == 1 and mean_weight == 0.5:
            p, fit = initial, None
        else:
            p, fit = problem.fit([0, 2, 3, 4, 6, 8], initial)
        record = summarize(problem, p, grid, pstar.electronic[keep])
        total, mean = problem.original_moments(p)
        record.update(
            optical_weight=optical_weight,
            mean_weight=mean_weight,
            optimizer_success=bool(fit.success) if fit else True,
            evaluations=int(fit.nfev) if fit else 0,
            mean_energy_rows=np.c_[
                RUDD_1979_N2_ENERGIES, RUDD_1979_N2_MEAN_ENERGIES, mean, total
            ].tolist(),
        )
        label = f"optical_{optical_weight}_mean_{mean_weight}"
        output["trials"][label] = record
        print(
            label,
            "mean ratio",
            record["rudd_1979_measured_mean_energy_ratio"],
            "optical",
            record["optical_fixed_channel_loss_density_ratio_25_100eV"],
            flush=True,
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    if args.figures:
        import matplotlib.pyplot as plt

        args.figures.mkdir(parents=True, exist_ok=True)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), constrained_layout=True)
        for label, record in output["trials"].items():
            row = np.asarray(record["mean_energy_rows"])
            name = f"Optical {record['optical_weight']}, mean {record['mean_weight']}"
            axes[0].semilogx(row[:, 0] / 1000, row[:, 2] / row[:, 1], label=name)
            stop = np.asarray(record["pair_to_pstar_rows"])
            axes[1].semilogx(stop[:, 0] / 1e6, stop[:, 1])
        axes[0].set(
            xlabel="Proton energy (keV)",
            ylabel="N₂ predicted / measured mean energy",
            title="Same six parameters; residual-weight sensitivity",
        )
        axes[1].set(
            xlabel="Proton energy (MeV)",
            ylabel="N₂ effective pair loss / NIST electronic",
            title="Stopping was not included in the fit",
        )
        for axis in axes:
            axis.axhline(1, color="black", linestyle=":", linewidth=1)
            axis.grid(alpha=0.2)
        axes[0].legend(fontsize=8)
        fig.savefig(args.figures / "n2_mean_weight_sensitivity.png", dpi=170)
        plt.close(fig)


if __name__ == "__main__":
    main()
