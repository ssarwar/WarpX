# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Independent integration and regression checks of the frozen energy model.

An agreement tolerance in these tests is a numerical or regression bound,
not an experimental uncertainty or proof of a complete molecular response.
"""

import unittest

import numpy as np
from audit_pjg_matched import bhabha
from calibrated_pjg import PARAMETERS, sdcs, total_cross_section
from finalize_pjg import centered_shape_residual
from pjg_matched import molecular_endpoint
from pjg_repair import TARGETS
from reference import free_maximum_transfer
from scipy.integrate import quad
from source_datasets import pjg_1976_figure5, rudd_1979_figure7
from stopping_pjg_matched import LossGrid, load_pstar, mass_stopping


class CalibrationChecks(unittest.TestCase):
    def test_parameter_reductions(self):
        for target, p in PARAMETERS.items():
            self.assertEqual(p.power, TARGETS[target].power)
            self.assertEqual(p.low_width_ratio, 1)
        self.assertEqual(PARAMETERS["O2"].edge_scale, 1)
        with self.assertRaises(TypeError):
            PARAMETERS["N2"] = PARAMETERS["O2"]

    def test_incident_range_and_secondary_validation(self):
        for target in PARAMETERS:
            for energy in (0, 4999, 1e10 + 1, np.nan, np.inf):
                with self.assertRaises(ValueError):
                    sdcs(target, energy, 0)
                with self.assertRaises(ValueError):
                    total_cross_section(target, energy)
            for secondary in (-1, np.nan, np.inf):
                with self.assertRaises(ValueError):
                    sdcs(target, 5e3, secondary)

    def test_total_against_independent_adaptive_quadrature(self):
        for target in PARAMETERS:
            for energy in (5e3, 50e3, 1e6):
                endpoint = molecular_endpoint(
                    target, energy, min(TARGETS[target].thresholds)
                )
                # Integrate directly in log(1+T), with no use of LossGrid's
                # segments or Jacobians. Scaling makes quad's absolute
                # tolerance meaningful for molecular cross sections.
                integral, _ = quad(
                    lambda x: (
                        float(sdcs(target, energy, np.expm1(x))) * np.exp(x) * 1e16
                    ),
                    0,
                    np.log1p(endpoint),
                    epsabs=1e-9,
                    epsrel=1e-10,
                    limit=200,
                )
                self.assertAlmostEqual(
                    integral / (total_cross_section(target, energy) * 1e16),
                    1,
                    delta=2e-8,
                )

    def test_shape_preserving_total_array_interface(self):
        energy = np.array([[5e3, 1e6], [1e6, 5e3]])
        for target in PARAMETERS:
            total = total_cross_section(target, energy)
            self.assertEqual(total.shape, energy.shape)
            self.assertEqual(total[0, 0], total[1, 1])
            self.assertEqual(total[0, 1], total[1, 0])

    def test_soft_limit_bound_tail_and_molecular_support(self):
        for target in PARAMETERS:
            for energy in (5e3, 50e3, 1e10):
                zero = sdcs(target, energy, 0)
                self.assertGreater(zero, 0)
                self.assertTrue(np.isfinite(zero))
                self.assertGreater(
                    sdcs(target, energy, free_maximum_transfer(energy) * 1.001), 0
                )
                endpoint = molecular_endpoint(
                    target, energy, min(TARGETS[target].thresholds)
                )
                np.testing.assert_array_equal(
                    sdcs(target, energy, endpoint * np.array([1, 1.01, 2])), 0
                )

    def test_hard_secondary_limit(self):
        for target in PARAMETERS:
            t = np.array([1e4, 1e5])
            ratio = sdcs(target, 800e6, t) / bhabha(target, 800e6, t)
            self.assertLess(abs(ratio[0] - 1), 0.002)
            self.assertLess(abs(ratio[1] - 1), 0.0002)

    def test_moment_inequalities_and_independent_stopping_budget(self):
        for target, p in PARAMETERS.items():
            table = load_pstar(target)
            keep = table.energies >= 5e3
            energy = table.energies[keep]
            m = LossGrid(target, energy, points=1025)(p)
            endpoint = molecular_endpoint(
                target, energy, min(TARGETS[target].thresholds)
            )
            self.assertTrue(np.all(m.kinetic**2 <= m.total * m.kinetic_second))
            self.assertTrue(np.all(m.kinetic_second <= endpoint * m.kinetic))
            self.assertTrue(np.all((m.tail_total > 0) & (m.tail_total < m.total)))
            self.assertTrue(
                np.all(mass_stopping(target, m.ionization) < table.electronic[keep])
            )

    def test_profiled_shape_is_normalization_invariant(self):
        ratio, weights = np.array([0.5, 1, 1.7]), np.array([0.5, 1, 1])
        np.testing.assert_allclose(
            centered_shape_residual(ratio, weights),
            centered_shape_residual(7.1 * ratio, weights),
            rtol=1e-14,
            atol=1e-15,
        )

    def test_measured_nitrogen_digitization_provenance_and_units(self):
        pjg = pjg_1976_figure5()
        rudd = rudd_1979_figure7()
        self.assertEqual(pjg.shape, (49, 4))
        self.assertEqual(rudd.shape, (18, 3))
        np.testing.assert_array_equal(np.unique(pjg[:, 0]), [5e4, 1e5, 3e5, 1e6])
        np.testing.assert_array_equal(np.unique(rudd[:, 0]), [5e3, 2e4, 7e4])
        for data in (pjg, rudd):
            self.assertTrue(np.all(data[:, :3] > 0))
            self.assertTrue(np.all((data[:, 2] > 1e-23) & (data[:, 2] < 1e-16)))
        # A decade in PJG's ordinate is 184 pixels. In Rudd's m^2/eV
        # ordinate it is 838/4 pixels; each reader returns cm^2/eV.
        np.testing.assert_allclose(
            pjg_1976_figure5((0, 184))[:, 2], pjg[:, 2] / 10, rtol=2e-14
        )
        np.testing.assert_allclose(
            rudd_1979_figure7((0, 838 / 4))[:, 2], rudd[:, 2] / 10, rtol=2e-14
        )


if __name__ == "__main__":
    unittest.main()
