# Copyright 2026 The WarpX Community
#
# This file is part of WarpX.
#
# License: BSD-3-Clause-LBNL

"""Check and visualize a source-refresh trial without promoting coefficients.

External source tables are supplied explicitly. Figures distinguish photon
energy from secondary energy, measurements from fitted recommendations,
and ionization-only loss from complete electronic stopping.
"""

import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np
from fit_pjg_matched import MomentGrid
from optical_dataset_audit import pjg_loss_density
from pjg_matched import MatchedParameters, SpectrumGrid
from reference import (
    BETHE_CONSTANT,
    ELECTRON_REST_ENERGY,
    PROTON_REST_ENERGY,
    rudd_sdcs,
)
from source_datasets import PHOTO_FACTOR, OpticalTable, cheng_1989_figure1, load_leiden
from stopping_pjg_matched import LossGrid, optical_strength
from study_source_refresh import SourceFitProblem

TRIAL = "six_optical_weight_1"


def source_optical(nifs, o2_path):
    table = np.asarray(nifs["N2"]["continuum"])
    return {
        "N2": OpticalTable(table[:, 0], table[:, 2]),
        "O2": load_leiden(o2_path)["ionization"],
    }


def numerical_checks(results, optical, multistart=False):
    output = {}
    for target in ("N2", "O2"):
        result = results["targets"][target]
        parameters = MatchedParameters(**result[TRIAL]["parameters"])
        energy = np.array([5e3, 50e3, 1e6, 800e6, 1e10])
        coarse = LossGrid(target, energy, points=1025)(parameters)
        fine = LossGrid(target, energy, points=4097)(parameters)
        convergence = {
            key: float(np.max(np.abs(getattr(coarse, key) / getattr(fine, key) - 1)))
            for key in ("total", "kinetic", "binding", "kinetic_second")
        }
        problem = SourceFitProblem(target, optical[target])
        fitted_total, fitted_mean = problem.moments(parameters)
        independent = LossGrid(target, problem.energies, points=4097)(parameters)
        smooth_total, smooth_mean = MomentGrid(target, problem.energies, points=4097)(
            parameters
        )
        output[target] = {
            "loss_grid_relative_change_1025_to_4097": convergence,
            "fitting_grid_total_relative_change_1025_to_4097": float(
                np.max(np.abs(fitted_total / smooth_total - 1))
            ),
            "fitting_grid_mean_relative_change_1025_to_4097": float(
                np.max(np.abs(fitted_mean / smooth_mean - 1))
            ),
            "different_grid_total_relative_difference": float(
                np.max(np.abs(fitted_total / independent.total - 1))
            ),
            "soft_oscillator_strength_by_trial": {
                label: optical_strength(target, MatchedParameters(**data["parameters"]))
                for label, data in result.items()
                if "parameters" in data
            },
        }
        if multistart:
            starts = (
                replace(parameters, j=parameters.j * 1.4, width=parameters.width * 0.8),
                replace(
                    parameters,
                    j=parameters.j * 0.7,
                    broad_excess=parameters.broad_excess * 1.3,
                ),
            )
            checks = []
            for start in starts:
                fitted, fit = problem.fit([0, 2, 3, 4, 6, 8], start)
                checks.append(
                    {
                        "success": bool(fit.success),
                        "evaluations": int(fit.nfev),
                        "objective_norm": float(np.linalg.norm(fit.fun)),
                        "maximum_spectral_relative_change": float(
                            np.max(
                                np.abs(
                                    problem.spectra(fitted)
                                    / problem.spectra(parameters)
                                    - 1
                                )
                            )
                        ),
                    }
                )
            output[target]["two_additional_starts"] = checks
    points = cheng_1989_figure1()
    index = int(np.where(points[:, 0] == 50e3)[0][-1])
    tail_ratios = []
    for dx in (-2, 2):
        for dy in (-2, 2):
            energy, secondary, measured = cheng_1989_figure1((dx, dy))[index]
            tail_ratios.append(float(rudd_sdcs("O2", energy, secondary) / measured))
    output["cheng_50keV_last_point"] = {
        "secondary_eV": float(points[index, 1]),
        "rudd_formula_to_digitized_ratio": float(
            rudd_sdcs("O2", *points[index, :2]) / points[index, 2]
        ),
        "two_pixel_corner_shift_ratio_range": [min(tail_ratios), max(tail_ratios)],
        "interpretation": "Sensitivity only, not an experimental confidence interval.",
    }
    return output


def plot_comparisons(results, optical, directory):
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}
    )
    labels = ("baseline", TRIAL, "six_optical_weight_2")
    names = (
        "Previous matched PJG",
        "Source trial: optical weight 1",
        "Source trial: optical weight 2",
    )
    colors = ("#737373", "#0072B2", "#D55E00")
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.4), constrained_layout=True)
    loss = np.geomspace(25, 100, 501)
    for column, target in enumerate(("N2", "O2")):
        for label, name, color in zip(labels, names, colors, strict=True):
            record = results["targets"][target][label]
            parameters = MatchedParameters(**record["parameters"])
            ratio = (
                PHOTO_FACTOR
                * pjg_loss_density(target, loss, parameters)
                / optical[target](loss)
            )
            axes[0, column].plot(loss, ratio, label=name, color=color)
            rows = np.asarray(record["pair_to_pstar_rows"])
            axes[1, column].semilogx(rows[:, 0] / 1e6, rows[:, 1], color=color)
        axes[0, column].set(
            title=f"{target}: fixed-channel optical diagnostic",
            xlabel="Photon / energy-loss energy W (eV)",
            ylabel="Model / evaluated optical response",
        )
        axes[1, column].set(
            title=f"{target}: effective-pair stopping only",
            xlabel="Proton kinetic energy (MeV)",
            ylabel="Pair loss / NIST electronic stopping",
            ylim=(0, 1.12),
        )
        for row in range(2):
            axes[row, column].axhline(1, color="#222222", linewidth=0.8, linestyle="--")
            axes[row, column].grid(alpha=0.2)
    axes[0, 0].legend(fontsize=8)
    fig.suptitle(
        "Provisional source sensitivity — no production coefficients changed",
        fontsize=13,
    )
    fig.savefig(directory / "source_optical_stopping.png", dpi=170)
    plt.close(fig)

    points = cheng_1989_figure1()
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.5), constrained_layout=True)
    t = np.geomspace(2, 600, 601)
    for axis, energy in zip(axes, (7.5e3, 50e3, 150e3), strict=True):
        group = points[points[:, 0] == energy]
        equivalent = energy * ELECTRON_REST_ENERGY / PROTON_REST_ENERGY

        def conversion(secondary):
            return equivalent * (secondary + 13.1) ** 2 / BETHE_CONSTANT

        axis.loglog(
            group[:, 1],
            group[:, 2] * conversion(group[:, 1]),
            "o",
            mfc="white",
            color="black",
            label="Cheng 1989 markers (rescaled)",
        )
        axis.loglog(
            t,
            rudd_sdcs("O2", energy, t) * conversion(t),
            "--",
            color="#009E73",
            label="Rudd 1992 formula",
        )
        for label, name, color in zip(labels[:2], names[:2], colors[:2], strict=True):
            parameters = MatchedParameters(
                **results["targets"]["O2"][label]["parameters"]
            )
            axis.loglog(
                t,
                SpectrumGrid("O2", energy, t)(parameters) * conversion(t),
                color=color,
                label=name,
            )
        axis.set(
            title=f"O2, {energy / 1000:g} keV protons",
            xlabel="Ejected-electron energy T (eV)",
            xlim=(2, 600),
        )
        measured_y = group[:, 2] * conversion(group[:, 1])
        axis.set_ylim(measured_y.min() / 4, measured_y.max() * 2)
        axis.grid(alpha=0.2, which="major")
    axes[0].set_ylabel("Reduced SDCS: K_NR (T + 13.1 eV)² S / C_B")
    axes[0].legend(fontsize=7, loc="lower left")
    fig.suptitle(
        "O2 measured spectral shapes — not independently measured absolute normalization",
        fontsize=12,
    )
    fig.savefig(directory / "cheng_1989_sdcs.png", dpi=170)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--nifs", type=Path, required=True)
    parser.add_argument("--o2-leiden", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--figures", type=Path)
    parser.add_argument("--multistart", action="store_true")
    args = parser.parse_args()
    results = json.loads(args.results.read_text())
    optical = source_optical(json.loads(args.nifs.read_text()), args.o2_leiden)
    output = numerical_checks(results, optical, args.multistart)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
    if args.figures:
        args.figures.mkdir(parents=True, exist_ok=True)
        plot_comparisons(results, optical, args.figures)


if __name__ == "__main__":
    main()
